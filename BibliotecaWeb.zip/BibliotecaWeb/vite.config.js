import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// El puerto 5173 está permitido en el CORS de BibliotecaAPI (appsettings.json → Cors:OrigenesPermitidos).
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, strictPort: true },
  preview: { port: 5173, strictPort: true },
});
