# Biblioteca Web (React + Vite)

Cliente web de **BibliotecaAPI** (ASP.NET Core Web API + JWT).
React 19, React Router 7, Vite y JavaScript. Sin librerías de UI: estilos propios en `src/index.css`.

## Puesta en marcha

1. Ejecuta **BibliotecaAPI** en Visual Studio con el perfil **http** (`http://localhost:5120`).
2. En esta carpeta:
   ```bash
   npm install
   npm run dev
   ```
3. Abre **http://localhost:5173** e inicia sesión con `admin@biblioteca.com` / `Admin12345`.

- La dirección del backend está en `.env` → `VITE_API_URL`. Si la cambias, reinicia `npm run dev`.
- El puerto **5173** ya está permitido en el CORS del backend (`appsettings.json` → `Cors:OrigenesPermitidos`).
  Si usas otro puerto, agrégalo ahí.
- Para generar la versión de producción: `npm run build` (queda en `dist/`).

## Funcionalidades

**Todos:** registro, login, inicio con resumen, catálogo con búsqueda, préstamo de **uno o varios libros**,
mis préstamos (filtro por estado), detalle de préstamo y perfil (`GET /api/usuarios/me`).

**Administrador – CRUD completo:**

| Entidad | Crear | Ver | Editar | Eliminar |
|---|---|---|---|---|
| Libros | *Nuevo libro* (modal) | Tabla con búsqueda | Lápiz → modal | Papelera (bloqueado si tiene historial) |
| Usuarios | *Nuevo usuario* con rol | Tabla con búsqueda + detalle con su historial de préstamos | Nombre, correo y rol | Papelera (bloqueado si tiene préstamos o eres tú) |
| Préstamos | *Nuevo préstamo* a nombre de cualquier usuario | Todos, filtro por estado y por usuario | *Registrar devolución* / *Reactivar* | *Eliminar* (devuelve el stock si estaba activo) |

> Crear usuario usa `POST /api/auth/register` y, si el rol es Administrador, `PUT /api/usuarios/{id}`.

## Seguridad

- El token JWT se guarda en `localStorage` y se envía en cada petición: `Authorization: Bearer <token>`.
- Al abrir la página se descarta la sesión si el token ya venció. Si el backend responde **401**, se cierra la sesión.
- `RutaPrivada` exige sesión; `RutaAdmin` oculta las páginas de administrador.
  **La seguridad real está en el backend** (`[Authorize(Roles = "Administrador")]`): la web solo evita mostrar
  opciones que el backend rechazaría con 403.
- Si la sesión vence o abres un enlace directo sin sesión, después del login vuelves a esa página.

## Estructura

```
src/
  main.jsx, App.jsx        Entrada y rutas (React Router)
  api/
    cliente.js             fetch + token JWT + mensajes de error del backend
    servicios.js           Un método por endpoint de BibliotecaAPI
  context/AuthContext.jsx  Sesión: login, logout, rol, vencimiento del token
  hooks/useCarga.js        Carga de datos (cargando / error / recargar) y debounce de búsquedas
  components/
    Layout.jsx             Barra lateral + contenido (menú hamburguesa en celular)
    Rutas.jsx              RutaPrivada, RutaAdmin, RutaPublica
    Avisos.jsx             Notificaciones y diálogo de confirmación
    Modal.jsx, ui.jsx      Botón, Campo, Insignia, Chips, estados de carga/error/vacío
  pages/                   Login, Registro, Inicio, Libros, Prestamos, NuevoPrestamo,
                           DetallePrestamo, Usuarios, DetalleUsuario, Perfil
  utils/fechas.js          Fechas UTC del backend → hora local
```
