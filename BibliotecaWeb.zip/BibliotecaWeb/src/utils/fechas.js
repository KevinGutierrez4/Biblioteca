/**
 * El backend guarda las fechas en UTC. Si llegan sin zona ("2026-10-27T18:00:00"),
 * se agrega "Z" para que el navegador no las interprete como hora local.
 */
export function parsearFecha(valor) {
  if (!valor) return null;
  const texto = String(valor);
  const tieneZona = /(Z|[+-]\d{2}:?\d{2})$/.test(texto);
  const fecha = new Date(tieneZona ? texto : `${texto}Z`);
  return isNaN(fecha.getTime()) ? null : fecha;
}

const dos = (n) => String(n).padStart(2, '0');

export function formatearFecha(valor, { conHora = true } = {}) {
  const f = parsearFecha(valor);
  if (!f) return '—';
  const dia = `${dos(f.getDate())}/${dos(f.getMonth() + 1)}/${f.getFullYear()}`;
  return conHora ? `${dia} ${dos(f.getHours())}:${dos(f.getMinutes())}` : dia;
}
