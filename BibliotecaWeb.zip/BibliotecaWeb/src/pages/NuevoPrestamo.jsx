import { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { BookOpen, CheckCircle2, Minus, Plus, Search, X } from 'lucide-react';
import { librosApi, prestamosApi, usuariosApi } from '../api/servicios';
import { useAuth } from '../context/AuthContext';
import { useAvisos } from '../components/Avisos';
import { useCarga } from '../hooks/useCarga';
import { Alerta, Boton, Cargando, Encabezado, ErrorCarga, Vacio } from '../components/ui';

const MAXIMO_POR_LIBRO = 100;

/**
 * Un préstamo puede incluir varios libros (relación N:M a través de DetallePrestamo).
 * El Administrador además elige a nombre de qué usuario se registra.
 */
export default function NuevoPrestamo() {
  const { esAdmin, usuario: yo } = useAuth();
  const { notificar } = useAvisos();
  const navigate = useNavigate();
  const [parametros] = useSearchParams();
  const libroInicial = parametros.get('libro');

  const { datos, cargando, error, recargar } = useCarga(
    () =>
      Promise.all([librosApi.listar(), esAdmin ? usuariosApi.listar() : Promise.resolve([])]).then(
        ([libros, usuarios]) => ({ libros, usuarios })
      ),
    [esAdmin]
  );

  // Selección: { idLibro: cantidad }. Si se llegó desde "Pedir", ese libro ya viene marcado.
  const [seleccion, setSeleccion] = useState(() => (libroInicial ? { [libroInicial]: 1 } : {}));
  const [idUsuario, setIdUsuario] = useState(String(yo?.idUsuario ?? ''));
  const [filtro, setFiltro] = useState('');
  const [errorEnvio, setErrorEnvio] = useState('');
  const [enviando, setEnviando] = useState(false);

  const libros = useMemo(() => datos?.libros ?? [], [datos]);
  const porId = useMemo(() => Object.fromEntries(libros.map((l) => [String(l.idLibro), l])), [libros]);

  // Quita de la selección libros que ya no existen o no tienen stock.
  const seleccionValida = useMemo(
    () =>
      Object.fromEntries(
        Object.entries(seleccion)
          .filter(([id]) => porId[id]?.cantidadDisponible > 0)
          .map(([id, c]) => [id, Math.min(c, porId[id].cantidadDisponible)])
      ),
    [seleccion, porId]
  );

  const visibles = useMemo(() => {
    const t = filtro.trim().toLowerCase();
    return t ? libros.filter((l) => `${l.titulo} ${l.autor}`.toLowerCase().includes(t)) : libros;
  }, [libros, filtro]);

  const total = Object.values(seleccionValida).reduce((s, c) => s + c, 0);

  function cambiar(libro, delta) {
    const id = String(libro.idLibro);
    setSeleccion((actual) => {
      const maximo = Math.min(libro.cantidadDisponible, MAXIMO_POR_LIBRO);
      const nueva = Math.max(0, Math.min(maximo, (actual[id] ?? 0) + delta));
      const copia = { ...actual };
      if (nueva === 0) delete copia[id];
      else copia[id] = nueva;
      return copia;
    });
  }

  async function confirmar() {
    setErrorEnvio('');
    const detalles = Object.entries(seleccionValida).map(([id, cantidad]) => ({
      idLibro: Number(id),
      cantidad,
    }));
    if (!detalles.length) return;
    setEnviando(true);
    try {
      const creado = await prestamosApi.crear(detalles, esAdmin ? Number(idUsuario) : undefined);
      notificar(`Préstamo #${creado.idPrestamo} registrado.`);
      navigate(`/prestamos/${creado.idPrestamo}`, { replace: true });
    } catch (e) {
      setErrorEnvio(e.message);
      setEnviando(false);
      if (e.status === 409) recargar(); // el stock cambió: se actualiza la lista
    }
  }

  if (cargando) return <Cargando />;
  if (error) return <ErrorCarga mensaje={error} onReintentar={recargar} />;

  return (
    <>
      <Encabezado titulo="Nuevo préstamo" subtitulo="Elige uno o varios libros y sus cantidades" />

      <div className="dos-columnas">
        <div className="tarjeta">
          <div className="buscador">
            <Search size={18} />
            <input
              placeholder="Filtrar por título o autor"
              value={filtro}
              onChange={(e) => setFiltro(e.target.value)}
              aria-label="Filtrar libros"
            />
          </div>
          {visibles.length === 0 ? (
            <Vacio icono={BookOpen} texto="No hay libros." />
          ) : (
            <ul className="lista-seleccion">
              {visibles.map((l) => {
                const cantidad = seleccionValida[String(l.idLibro)] ?? 0;
                const agotado = l.cantidadDisponible === 0;
                const maximo = Math.min(l.cantidadDisponible, MAXIMO_POR_LIBRO);
                return (
                  <li key={l.idLibro} className={`${cantidad > 0 ? 'seleccionado' : ''} ${agotado ? 'agotado' : ''}`}>
                    <div className="lista-info">
                      <strong>{l.titulo}</strong>
                      <span className="texto-suave">{l.autor}</span>
                      <span className={agotado ? 'color-peligro texto-pequeno' : 'color-exito texto-pequeno'}>
                        {agotado ? 'Agotado' : `${l.cantidadDisponible} disponibles`}
                      </span>
                    </div>
                    <div className="contador">
                      <button
                        className="boton-cantidad"
                        disabled={cantidad === 0}
                        onClick={() => cambiar(l, -1)}
                        aria-label={`Quitar ${l.titulo}`}
                      >
                        <Minus size={16} />
                      </button>
                      <span className="contador-valor">{cantidad}</span>
                      <button
                        className="boton-cantidad"
                        disabled={agotado || cantidad >= maximo}
                        onClick={() => cambiar(l, 1)}
                        aria-label={`Agregar ${l.titulo}`}
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <aside className="tarjeta resumen">
          <h2>Resumen</h2>

          {esAdmin ? (
            <label className="campo">
              <span className="etiqueta">Registrar a nombre de</span>
              <select className="select" value={idUsuario} onChange={(e) => setIdUsuario(e.target.value)}>
                {datos.usuarios.map((u) => (
                  <option key={u.idUsuario} value={u.idUsuario}>
                    {u.nombre}
                    {u.idUsuario === yo?.idUsuario ? ' (yo)' : ''}
                  </option>
                ))}
              </select>
            </label>
          ) : null}

          {total === 0 ? (
            <p className="texto-suave">Ningún libro seleccionado.</p>
          ) : (
            <ul className="lista-resumen">
              {Object.entries(seleccionValida).map(([id, c]) => (
                <li key={id}>
                  <span className="recortar">{porId[id].titulo}</span>
                  <span className="texto-primario">x{c}</span>
                  <button
                    className="boton-icono"
                    onClick={() => cambiar(porId[id], -c)}
                    aria-label={`Quitar ${porId[id].titulo} del préstamo`}
                  >
                    <X size={16} />
                  </button>
                </li>
              ))}
            </ul>
          )}

          <div className="resumen-total">
            <span>Total</span>
            <strong>
              {total} {total === 1 ? 'libro' : 'libros'}
            </strong>
          </div>

          <Alerta>{errorEnvio}</Alerta>

          <Boton icono={CheckCircle2} disabled={total === 0} cargando={enviando} onClick={confirmar} className="ancho-completo">
            Confirmar préstamo
          </Boton>
          <Boton variante="secundario" onClick={() => navigate(-1)} className="ancho-completo">
            Cancelar
          </Boton>
        </aside>
      </div>
    </>
  );
}
