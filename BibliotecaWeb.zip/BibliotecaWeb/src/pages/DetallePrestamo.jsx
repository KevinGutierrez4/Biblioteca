import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, BookOpen, CheckCheck, RotateCcw, Trash2 } from 'lucide-react';
import { prestamosApi } from '../api/servicios';
import { useAuth } from '../context/AuthContext';
import { useAvisos } from '../components/Avisos';
import { useCarga } from '../hooks/useCarga';
import { Boton, Cargando, ErrorCarga, EstadoPrestamo } from '../components/ui';
import { formatearFecha } from '../utils/fechas';

export default function DetallePrestamo() {
  const { id } = useParams();
  const { esAdmin } = useAuth();
  const { confirmar, notificar } = useAvisos();
  const navigate = useNavigate();
  const { datos: prestamo, cargando, error, recargar, setDatos } = useCarga(() => prestamosApi.obtener(id), [id]);
  const [procesando, setProcesando] = useState('');

  async function cambiarEstado(nuevo) {
    const devolver = nuevo === 'Devuelto';
    const ok = await confirmar(
      devolver ? 'Registrar devolución' : 'Reactivar préstamo',
      devolver
        ? 'Se registrará la fecha de devolución y los libros volverán al stock.'
        : 'El préstamo volverá a estar activo y se descontará el stock.',
      devolver ? 'Registrar devolución' : 'Reactivar',
      false
    );
    if (!ok) return;
    setProcesando('estado');
    try {
      setDatos(await prestamosApi.cambiarEstado(id, nuevo));
      notificar(devolver ? 'Devolución registrada.' : 'Préstamo reactivado.');
    } catch (e) {
      notificar(e.message, 'error');
    } finally {
      setProcesando('');
    }
  }

  async function eliminar() {
    const extra = prestamo.estado === 'Activo' ? ' Los libros volverán al stock.' : '';
    if (!(await confirmar('Eliminar préstamo', `¿Eliminar el préstamo #${id}?${extra}`, 'Eliminar'))) return;
    setProcesando('eliminar');
    try {
      await prestamosApi.eliminar(id);
      notificar('Préstamo eliminado.');
      navigate('/prestamos', { replace: true });
    } catch (e) {
      notificar(e.message, 'error');
      setProcesando('');
    }
  }

  if (cargando) return <Cargando />;
  if (error) return <ErrorCarga mensaje={error} onReintentar={recargar} />;

  const activo = prestamo.estado === 'Activo';
  const total = prestamo.detalles.reduce((s, d) => s + d.cantidad, 0);

  return (
    <>
      <Link to="/prestamos" className="volver">
        <ArrowLeft size={16} /> Préstamos
      </Link>

      <div className="encabezado">
        <div>
          <h1>
            Préstamo #{prestamo.idPrestamo} <EstadoPrestamo estado={prestamo.estado} />
          </h1>
          <p>Registrado el {formatearFecha(prestamo.fechaPrestamo)}</p>
        </div>
        {esAdmin ? (
          <div className="encabezado-acciones">
            {activo ? (
              <Boton variante="exito" icono={CheckCheck} cargando={procesando === 'estado'} onClick={() => cambiarEstado('Devuelto')}>
                Registrar devolución
              </Boton>
            ) : (
              <Boton variante="secundario" icono={RotateCcw} cargando={procesando === 'estado'} onClick={() => cambiarEstado('Activo')}>
                Reactivar
              </Boton>
            )}
            <Boton variante="peligro" icono={Trash2} cargando={procesando === 'eliminar'} onClick={eliminar}>
              Eliminar
            </Boton>
          </div>
        ) : null}
      </div>

      <div className="dos-columnas inversa">
        <section className="tarjeta">
          <h2>Libros ({total})</h2>
          <div className="tabla-contenedor">
            <table className="tabla">
              <thead>
                <tr>
                  <th>Título</th>
                  <th>Autor</th>
                  <th className="derecha">Cantidad</th>
                </tr>
              </thead>
              <tbody>
                {prestamo.detalles.map((d) => (
                  <tr key={d.idDetalle}>
                    <td className="celda-fuerte">
                      <BookOpen size={16} className="color-primario icono-en-linea" /> {d.titulo}
                    </td>
                    <td>{d.autor}</td>
                    <td className="derecha">{d.cantidad}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <aside className="tarjeta">
          <h2>Datos</h2>
          <dl className="datos">
            <dt>Usuario</dt>
            <dd>
              {esAdmin ? (
                <Link to={`/usuarios/${prestamo.usuario.idUsuario}`}>{prestamo.usuario.nombre}</Link>
              ) : (
                prestamo.usuario.nombre
              )}
            </dd>
            <dt>Correo</dt>
            <dd>{prestamo.usuario.correo}</dd>
            <dt>Fecha de préstamo</dt>
            <dd>{formatearFecha(prestamo.fechaPrestamo)}</dd>
            <dt>Devolución</dt>
            <dd>{prestamo.fechaDevolucion ? formatearFecha(prestamo.fechaDevolucion) : 'Pendiente'}</dd>
          </dl>
          {!esAdmin && activo ? (
            <p className="nota">Para devolver los libros acércate a la biblioteca: el administrador registrará la devolución.</p>
          ) : null}
        </aside>
      </div>
    </>
  );
}
