import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowLeftRight, Save, Trash2 } from 'lucide-react';
import { prestamosApi, usuariosApi } from '../api/servicios';
import { useAuth } from '../context/AuthContext';
import { useAvisos } from '../components/Avisos';
import { useCarga } from '../hooks/useCarga';
import { Alerta, Boton, Campo, Cargando, ErrorCarga, Vacio, EstadoPrestamo } from '../components/ui';
import { formatearFecha } from '../utils/fechas';

export default function DetalleUsuario() {
  const { id } = useParams();
  const { datos, cargando, error, recargar } = useCarga(
    () =>
      Promise.all([usuariosApi.obtener(id), prestamosApi.listar({ idUsuario: id })]).then(
        ([usuario, prestamos]) => ({ usuario, prestamos })
      ),
    [id]
  );

  if (cargando) return <Cargando />;
  if (error) return <ErrorCarga mensaje={error} onReintentar={recargar} />;

  // "key" reinicia el formulario si se navega a otro usuario.
  return <Contenido key={id} usuario={datos.usuario} prestamos={datos.prestamos} />;
}

function Contenido({ usuario, prestamos }) {
  const { usuario: yo, actualizarUsuario } = useAuth();
  const { confirmar, notificar } = useAvisos();
  const navigate = useNavigate();
  const soyYo = usuario.idUsuario === yo?.idUsuario;

  const [form, setForm] = useState({ nombre: usuario.nombre, correo: usuario.correo, rol: usuario.rol });
  const [error, setError] = useState('');
  const [procesando, setProcesando] = useState('');

  const cambiar = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  async function guardar(ev) {
    ev.preventDefault();
    setError('');
    if (!form.nombre.trim() || !form.correo.trim()) {
      setError('Nombre y correo son obligatorios.');
      return;
    }
    setProcesando('guardar');
    try {
      const actualizado = await usuariosApi.actualizar(usuario.idUsuario, {
        nombre: form.nombre.trim(),
        correo: form.correo.trim(),
        rol: form.rol,
      });
      if (soyYo) actualizarUsuario(actualizado);
      notificar('Cambios guardados.');
      navigate('/usuarios');
    } catch (err) {
      setError(err.message);
      setProcesando('');
    }
  }

  async function eliminar() {
    if (!(await confirmar('Eliminar usuario', `¿Eliminar a ${usuario.nombre}?`, 'Eliminar'))) return;
    setProcesando('eliminar');
    try {
      await usuariosApi.eliminar(usuario.idUsuario);
      notificar('Usuario eliminado.');
      navigate('/usuarios', { replace: true });
    } catch (err) {
      notificar(err.message, 'error');
      setProcesando('');
    }
  }

  return (
    <>
      <Link to="/usuarios" className="volver">
        <ArrowLeft size={16} /> Usuarios
      </Link>
      <div className="encabezado">
        <div>
          <h1>{usuario.nombre}</h1>
          <p>{usuario.correo}</p>
        </div>
      </div>

      <div className="dos-columnas">
        <section className="tarjeta">
          <h2>Préstamos de este usuario ({prestamos.length})</h2>
          {prestamos.length === 0 ? (
            <Vacio icono={ArrowLeftRight} texto="Todavía no tiene préstamos." />
          ) : (
            <ul className="lista-simple">
              {prestamos.map((p) => (
                <li key={p.idPrestamo} onClick={() => navigate(`/prestamos/${p.idPrestamo}`)}>
                  <div>
                    <strong>Préstamo #{p.idPrestamo}</strong>
                    <p className="texto-suave recortar">
                      {p.detalles.map((d) => (d.cantidad > 1 ? `${d.titulo} (x${d.cantidad})` : d.titulo)).join(' · ')}
                    </p>
                  </div>
                  <div className="lista-derecha">
                    <EstadoPrestamo estado={p.estado} />
                    <span className="texto-pequeno">{formatearFecha(p.fechaPrestamo)}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <aside className="tarjeta">
          <h2>Editar datos</h2>
          <form onSubmit={guardar}>
            <Campo etiqueta="Nombre" name="nombre" value={form.nombre} onChange={cambiar} />
            <Campo etiqueta="Correo" name="correo" type="email" value={form.correo} onChange={cambiar} />
            <Campo etiqueta="Rol">
              <select name="rol" className="select" value={form.rol} onChange={cambiar} disabled={soyYo}>
                <option value="Usuario">Usuario</option>
                <option value="Administrador">Administrador</option>
              </select>
            </Campo>
            {soyYo ? <p className="nota">No puedes cambiar tu propio rol.</p> : null}
            <Alerta>{error}</Alerta>
            <Boton type="submit" icono={Save} cargando={procesando === 'guardar'} className="ancho-completo">
              Guardar cambios
            </Boton>
          </form>

          {!soyYo ? (
            <div className="zona-peligro">
              <Boton
                variante="peligro"
                icono={Trash2}
                cargando={procesando === 'eliminar'}
                disabled={prestamos.length > 0}
                onClick={eliminar}
                className="ancho-completo"
              >
                Eliminar usuario
              </Boton>
              {prestamos.length > 0 ? (
                <p className="nota">No se puede eliminar un usuario con historial de préstamos.</p>
              ) : null}
            </div>
          ) : null}
        </aside>
      </div>
    </>
  );
}
