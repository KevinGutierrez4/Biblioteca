import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeftRight, Plus } from 'lucide-react';
import { prestamosApi, usuariosApi } from '../api/servicios';
import { useAuth } from '../context/AuthContext';
import { useCarga } from '../hooks/useCarga';
import { Boton, Cargando, Chips, Encabezado, ErrorCarga, Vacio, EstadoPrestamo } from '../components/ui';
import { formatearFecha } from '../utils/fechas';

const FILTROS = [
  { valor: '', texto: 'Todos' },
  { valor: 'Activo', texto: 'Activos' },
  { valor: 'Devuelto', texto: 'Devueltos' },
];

export default function Prestamos() {
  const { esAdmin } = useAuth();
  const navigate = useNavigate();

  const [estado, setEstado] = useState('');
  const [idUsuario, setIdUsuario] = useState('');

  const { datos: prestamos, cargando, error, recargar } = useCarga(
    () => prestamosApi.listar({ estado, idUsuario: idUsuario || undefined }),
    [estado, idUsuario]
  );
  // Lista de usuarios para el filtro (solo Administrador).
  const { datos: usuarios } = useCarga(
    () => (esAdmin ? usuariosApi.listar() : Promise.resolve([])),
    [esAdmin]
  );

  return (
    <>
      <Encabezado
        titulo="Préstamos"
        subtitulo={esAdmin ? 'Préstamos de todos los usuarios' : 'Tus préstamos'}
      >
        <Boton icono={Plus} onClick={() => navigate('/prestamos/nuevo')}>
          Nuevo préstamo
        </Boton>
      </Encabezado>

      <div className="tarjeta">
        <div className="filtros">
          <Chips opciones={FILTROS} valor={estado} onCambiar={setEstado} />
          {esAdmin && usuarios?.length ? (
            <select
              className="select"
              value={idUsuario}
              onChange={(e) => setIdUsuario(e.target.value)}
              aria-label="Filtrar por usuario"
            >
              <option value="">Todos los usuarios</option>
              {usuarios.map((u) => (
                <option key={u.idUsuario} value={u.idUsuario}>
                  {u.nombre}
                </option>
              ))}
            </select>
          ) : null}
        </div>

        {cargando ? (
          <Cargando />
        ) : error && !prestamos ? (
          <ErrorCarga mensaje={error} onReintentar={recargar} />
        ) : prestamos.length === 0 ? (
          <Vacio icono={ArrowLeftRight} texto="No hay préstamos para mostrar." />
        ) : (
          <div className="tabla-contenedor">
            <table className="tabla tabla-clic">
              <thead>
                <tr>
                  <th>#</th>
                  {esAdmin ? <th>Usuario</th> : null}
                  <th>Libros</th>
                  <th>Fecha de préstamo</th>
                  <th>Devolución</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                {prestamos.map((p) => (
                  <tr key={p.idPrestamo} onClick={() => navigate(`/prestamos/${p.idPrestamo}`)}>
                    <td className="celda-fuerte">{p.idPrestamo}</td>
                    {esAdmin ? <td>{p.usuario.nombre}</td> : null}
                    <td className="celda-libros">
                      {p.detalles
                        .map((d) => (d.cantidad > 1 ? `${d.titulo} (x${d.cantidad})` : d.titulo))
                        .join(' · ')}
                    </td>
                    <td>{formatearFecha(p.fechaPrestamo)}</td>
                    <td>{p.fechaDevolucion ? formatearFecha(p.fechaDevolucion) : <span className="texto-suave">Pendiente</span>}</td>
                    <td><EstadoPrestamo estado={p.estado} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
