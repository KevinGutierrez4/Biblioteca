import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Eye, EyeOff, Library, LogIn } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Alerta, Boton, Campo } from '../components/ui';
import { API_URL } from '../api/cliente';

export default function Login() {
  const { iniciarSesion } = useAuth();

  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [verPassword, setVerPassword] = useState(false);
  const [error, setError] = useState('');
  const [enviando, setEnviando] = useState(false);

  async function enviar(e) {
    e.preventDefault();
    setError('');
    if (!correo.trim() || !password) {
      setError('Escribe tu correo y contraseña.');
      return;
    }
    setEnviando(true);
    try {
      // Al haber sesión, RutaPublica redirige a la página que se quería abrir.
      await iniciarSesion(correo, password);
    } catch (err) {
      setError(err.message);
      setEnviando(false);
    }
  }

  return (
    <div className="pantalla-auth">
      <section className="auth-portada">
        <div className="marca grande">
          <div className="marca-logo">
            <Library size={28} />
          </div>
          <span>Biblioteca</span>
        </div>
        <h2>Gestiona libros, usuarios y préstamos desde un solo lugar.</h2>
        <p>Cliente web de BibliotecaAPI · ASP.NET Core Web API + JWT</p>
      </section>

      <section className="auth-formulario">
        <form onSubmit={enviar} className="tarjeta-auth">
          <h1>Iniciar sesión</h1>
          <p className="texto-suave">Ingresa con tu cuenta para continuar.</p>

          <Campo
            etiqueta="Correo"
            name="correo"
            type="email"
            autoComplete="email"
            placeholder="admin@biblioteca.com"
            value={correo}
            onChange={(e) => setCorreo(e.target.value)}
          />
          <Campo etiqueta="Contraseña">
            <div className="input-con-boton">
              <input
                id="password"
                type={verPassword ? 'text' : 'password'}
                autoComplete="current-password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button
                type="button"
                className="boton-icono"
                onClick={() => setVerPassword((v) => !v)}
                aria-label={verPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
              >
                {verPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </Campo>

          <Alerta>{error}</Alerta>

          <Boton type="submit" icono={LogIn} cargando={enviando} className="ancho-completo">
            Ingresar
          </Boton>

          <p className="texto-centro">
            ¿No tienes cuenta? <Link to="/registro">Regístrate</Link>
          </p>
          <p className="texto-servidor">Servidor: {API_URL}</p>
        </form>
      </section>
    </div>
  );
}
