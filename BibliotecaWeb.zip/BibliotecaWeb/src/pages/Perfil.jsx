import { useEffect } from 'react';
import { LogOut } from 'lucide-react';
import { usuariosApi } from '../api/servicios';
import { API_URL } from '../api/cliente';
import { useAuth } from '../context/AuthContext';
import { useAvisos } from '../components/Avisos';
import { Boton, Encabezado, Insignia } from '../components/ui';
import { formatearFecha } from '../utils/fechas';

export default function Perfil() {
  const { usuario, sesion, cerrarSesion, actualizarUsuario } = useAuth();
  const { confirmar } = useAvisos();

  // Consulta GET /api/usuarios/me para mostrar los datos actuales del backend.
  useEffect(() => {
    usuariosApi.yo().then(actualizarUsuario).catch(() => {});
  }, [actualizarUsuario]);

  async function salir() {
    if (await confirmar('Cerrar sesión', '¿Seguro que quieres salir?', 'Salir')) {
      cerrarSesion({ manual: true }); // RutaPrivada lleva al login
    }
  }

  return (
    <>
      <Encabezado titulo="Mi perfil" />
      <div className="tarjeta perfil">
        <div className="avatar grande">{(usuario?.nombre || '?').charAt(0).toUpperCase()}</div>
        <div className="perfil-datos">
          <h2>{usuario?.nombre}</h2>
          <p className="texto-suave">{usuario?.correo}</p>
          <Insignia tipo={usuario?.rol === 'Administrador' ? 'info' : 'exito'}>{usuario?.rol}</Insignia>
        </div>
      </div>
      <div className="tarjeta">
        <dl className="datos">
          <dt>Servidor (BibliotecaAPI)</dt>
          <dd className="texto-mono">{API_URL}</dd>
          <dt>La sesión vence</dt>
          <dd>{formatearFecha(sesion?.expiracion)}</dd>
          <dt>Token</dt>
          <dd>JWT guardado en el navegador (localStorage)</dd>
        </dl>
        <Boton variante="peligro" icono={LogOut} onClick={salir}>
          Cerrar sesión
        </Boton>
      </div>
    </>
  );
}
