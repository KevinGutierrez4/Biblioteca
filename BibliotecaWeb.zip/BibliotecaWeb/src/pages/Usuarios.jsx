import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Pencil, Search, ShieldCheck, Trash2, User, UserPlus, Users } from 'lucide-react';
import { authApi, usuariosApi } from '../api/servicios';
import { useAuth } from '../context/AuthContext';
import { useAvisos } from '../components/Avisos';
import { useCarga } from '../hooks/useCarga';
import Modal from '../components/Modal';
import { Alerta, Boton, Campo, Cargando, Encabezado, ErrorCarga, Insignia, Vacio } from '../components/ui';

const CORREO_VALIDO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Usuarios() {
  const { usuario: yo } = useAuth();
  const { confirmar, notificar } = useAvisos();
  const navigate = useNavigate();
  const { datos: usuarios, cargando, error, recargar } = useCarga(() => usuariosApi.listar(), []);
  const [buscar, setBuscar] = useState('');
  const [creando, setCreando] = useState(false);

  const visibles = useMemo(() => {
    const t = buscar.trim().toLowerCase();
    const lista = usuarios ?? [];
    return t ? lista.filter((u) => `${u.nombre} ${u.correo}`.toLowerCase().includes(t)) : lista;
  }, [usuarios, buscar]);

  async function eliminar(u) {
    if (!(await confirmar('Eliminar usuario', `¿Eliminar a ${u.nombre}?`, 'Eliminar'))) return;
    try {
      await usuariosApi.eliminar(u.idUsuario);
      notificar('Usuario eliminado.');
      recargar();
    } catch (e) {
      notificar(e.message, 'error');
    }
  }

  return (
    <>
      <Encabezado titulo="Usuarios" subtitulo="Cuentas registradas y sus roles">
        <Boton icono={UserPlus} onClick={() => setCreando(true)}>
          Nuevo usuario
        </Boton>
      </Encabezado>

      <div className="tarjeta">
        <div className="buscador">
          <Search size={18} />
          <input
            placeholder="Buscar por nombre o correo"
            value={buscar}
            onChange={(e) => setBuscar(e.target.value)}
            aria-label="Buscar usuarios"
          />
        </div>

        {cargando ? (
          <Cargando />
        ) : error ? (
          <ErrorCarga mensaje={error} onReintentar={recargar} />
        ) : visibles.length === 0 ? (
          <Vacio icono={Users} texto="No hay usuarios que coincidan." />
        ) : (
          <div className="tabla-contenedor">
            <table className="tabla">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Correo</th>
                  <th>Rol</th>
                  <th className="col-acciones">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {visibles.map((u) => {
                  const soyYo = u.idUsuario === yo?.idUsuario;
                  return (
                    <tr key={u.idUsuario}>
                      <td className="celda-fuerte">
                        {u.rol === 'Administrador' ? (
                          <ShieldCheck size={16} className="color-primario icono-en-linea" />
                        ) : (
                          <User size={16} className="texto-suave icono-en-linea" />
                        )}{' '}
                        {u.nombre}
                        {soyYo ? <span className="texto-suave"> (tú)</span> : null}
                      </td>
                      <td>{u.correo}</td>
                      <td>
                        <Insignia tipo={u.rol === 'Administrador' ? 'info' : 'exito'}>{u.rol}</Insignia>
                      </td>
                      <td className="col-acciones">
                        <div className="acciones-fila">
                          <button
                            className="boton-icono"
                            title="Ver y editar"
                            aria-label={`Editar ${u.nombre}`}
                            onClick={() => navigate(`/usuarios/${u.idUsuario}`)}
                          >
                            <Pencil size={18} />
                          </button>
                          <button
                            className="boton-icono peligro"
                            title={soyYo ? 'No puedes eliminar tu propia cuenta' : 'Eliminar'}
                            aria-label={`Eliminar ${u.nombre}`}
                            disabled={soyYo}
                            onClick={() => eliminar(u)}
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {creando ? (
        <NuevoUsuario
          onCerrar={() => setCreando(false)}
          onCreado={() => {
            setCreando(false);
            notificar('Usuario creado.');
            recargar();
          }}
        />
      ) : null}
    </>
  );
}

/**
 * Crear usuario:
 * 1) POST /api/auth/register (crea la cuenta con rol "Usuario").
 * 2) Si se eligió "Administrador", PUT /api/usuarios/{id} asigna el rol.
 */
function NuevoUsuario({ onCerrar, onCreado }) {
  const [form, setForm] = useState({ nombre: '', correo: '', password: '', rol: 'Usuario' });
  const [errores, setErrores] = useState({});
  const [error, setError] = useState('');
  const [guardando, setGuardando] = useState(false);

  const cambiar = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  async function guardar(ev) {
    ev.preventDefault();
    setError('');
    const e = {};
    if (!form.nombre.trim()) e.nombre = 'El nombre es obligatorio.';
    if (!CORREO_VALIDO.test(form.correo.trim())) e.correo = 'Escribe un correo válido.';
    if (form.password.length < 8) e.password = 'Mínimo 8 caracteres.';
    setErrores(e);
    if (Object.keys(e).length) return;

    setGuardando(true);
    try {
      const creado = await authApi.registro(form.nombre.trim(), form.correo.trim(), form.password);
      if (form.rol === 'Administrador') {
        await usuariosApi.actualizar(creado.idUsuario, {
          nombre: creado.nombre,
          correo: creado.correo,
          rol: form.rol,
        });
      }
      onCreado();
    } catch (err) {
      setError(err.message);
      setGuardando(false);
    }
  }

  return (
    <Modal titulo="Nuevo usuario" abierto onCerrar={onCerrar}>
      <form onSubmit={guardar}>
        <Campo etiqueta="Nombre" name="nombre" value={form.nombre} onChange={cambiar} error={errores.nombre} autoFocus />
        <Campo etiqueta="Correo" name="correo" type="email" value={form.correo} onChange={cambiar} error={errores.correo} />
        <div className="fila-campos">
          <Campo
            etiqueta="Contraseña inicial"
            name="password"
            type="password"
            placeholder="Mínimo 8 caracteres"
            value={form.password}
            onChange={cambiar}
            error={errores.password}
          />
          <Campo etiqueta="Rol">
            <select name="rol" className="select" value={form.rol} onChange={cambiar}>
              <option value="Usuario">Usuario</option>
              <option value="Administrador">Administrador</option>
            </select>
          </Campo>
        </div>
        <Alerta>{error}</Alerta>
        <div className="acciones-derecha">
          <Boton type="button" variante="secundario" onClick={onCerrar}>
            Cancelar
          </Boton>
          <Boton type="submit" cargando={guardando}>
            Crear usuario
          </Boton>
        </div>
      </form>
    </Modal>
  );
}
