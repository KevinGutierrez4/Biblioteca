import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, Bookmark, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { librosApi } from '../api/servicios';
import { useAuth } from '../context/AuthContext';
import { useAvisos } from '../components/Avisos';
import { useCarga, useDebounce } from '../hooks/useCarga';
import Modal from '../components/Modal';
import { Alerta, Boton, Campo, Cargando, Encabezado, ErrorCarga, Insignia, Vacio } from '../components/ui';

export default function Libros() {
  const { esAdmin } = useAuth();
  const { confirmar, notificar } = useAvisos();
  const navigate = useNavigate();

  const [buscar, setBuscar] = useState('');
  const busqueda = useDebounce(buscar.trim());
  const { datos: libros, cargando, error, recargar } = useCarga(() => librosApi.listar(busqueda), [busqueda]);

  const [editando, setEditando] = useState(null); // null = cerrado, {} = nuevo, libro = editar

  async function eliminar(libro) {
    if (!(await confirmar('Eliminar libro', `¿Eliminar "${libro.titulo}"? Esta acción no se puede deshacer.`, 'Eliminar'))) return;
    try {
      await librosApi.eliminar(libro.idLibro);
      notificar('Libro eliminado.');
      recargar();
    } catch (e) {
      notificar(e.message, 'error');
    }
  }

  return (
    <>
      <Encabezado titulo="Libros" subtitulo="Catálogo y ejemplares disponibles">
        {esAdmin ? (
          <Boton icono={Plus} onClick={() => setEditando({})}>
            Nuevo libro
          </Boton>
        ) : null}
      </Encabezado>

      <div className="tarjeta">
        <div className="buscador">
          <Search size={18} />
          <input
            placeholder="Buscar por título, autor o ISBN"
            value={buscar}
            onChange={(e) => setBuscar(e.target.value)}
            aria-label="Buscar libros"
          />
        </div>

        {cargando ? (
          <Cargando />
        ) : error && !libros ? (
          <ErrorCarga mensaje={error} onReintentar={recargar} />
        ) : libros.length === 0 ? (
          <Vacio icono={BookOpen} texto={busqueda ? 'No hay libros que coincidan.' : 'Aún no hay libros registrados.'} />
        ) : (
          <div className="tabla-contenedor">
            <table className="tabla">
              <thead>
                <tr>
                  <th>Título</th>
                  <th>Autor</th>
                  <th>ISBN</th>
                  <th>Disponibles</th>
                  <th className="col-acciones">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {libros.map((l) => (
                  <tr key={l.idLibro}>
                    <td className="celda-fuerte">{l.titulo}</td>
                    <td>{l.autor}</td>
                    <td className="texto-mono">{l.isbn}</td>
                    <td>
                      {l.cantidadDisponible > 0 ? (
                        <Insignia tipo="exito">{l.cantidadDisponible}</Insignia>
                      ) : (
                        <Insignia tipo="peligro">Agotado</Insignia>
                      )}
                    </td>
                    <td className="col-acciones">
                      <div className="acciones-fila">
                        <Boton
                          variante="secundario"
                          icono={Bookmark}
                          disabled={l.cantidadDisponible === 0}
                          onClick={() => navigate(`/prestamos/nuevo?libro=${l.idLibro}`)}
                        >
                          Pedir
                        </Boton>
                        {esAdmin ? (
                          <>
                            <button className="boton-icono" title="Editar" aria-label={`Editar ${l.titulo}`} onClick={() => setEditando(l)}>
                              <Pencil size={18} />
                            </button>
                            <button className="boton-icono peligro" title="Eliminar" aria-label={`Eliminar ${l.titulo}`} onClick={() => eliminar(l)}>
                              <Trash2 size={18} />
                            </button>
                          </>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {editando ? (
        <FormularioLibro
          libro={editando}
          onCerrar={() => setEditando(null)}
          onGuardado={(mensaje) => {
            setEditando(null);
            notificar(mensaje);
            recargar();
          }}
        />
      ) : null}
    </>
  );
}

/** Modal para crear (libro = {}) o editar un libro. Solo Administrador. */
function FormularioLibro({ libro, onCerrar, onGuardado }) {
  const editando = !!libro.idLibro;
  const [form, setForm] = useState({
    titulo: libro.titulo ?? '',
    autor: libro.autor ?? '',
    isbn: libro.isbn ?? '',
    cantidadDisponible: String(libro.cantidadDisponible ?? 1),
  });
  const [errores, setErrores] = useState({});
  const [error, setError] = useState('');
  const [guardando, setGuardando] = useState(false);

  const cambiar = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  function validar() {
    const e = {};
    if (!form.titulo.trim()) e.titulo = 'El título es obligatorio.';
    else if (form.titulo.trim().length > 150) e.titulo = 'Máximo 150 caracteres.';
    if (!form.autor.trim()) e.autor = 'El autor es obligatorio.';
    else if (form.autor.trim().length > 100) e.autor = 'Máximo 100 caracteres.';
    if (!form.isbn.trim()) e.isbn = 'El ISBN es obligatorio.';
    else if (form.isbn.trim().length > 20) e.isbn = 'Máximo 20 caracteres.';
    const n = Number(form.cantidadDisponible);
    if (!/^\d+$/.test(form.cantidadDisponible) || n > 10000) e.cantidadDisponible = 'Número entre 0 y 10000.';
    setErrores(e);
    return Object.keys(e).length === 0;
  }

  async function guardar(ev) {
    ev.preventDefault();
    setError('');
    if (!validar()) return;
    setGuardando(true);
    const datos = {
      titulo: form.titulo.trim(),
      autor: form.autor.trim(),
      isbn: form.isbn.trim(),
      cantidadDisponible: Number(form.cantidadDisponible),
    };
    try {
      if (editando) await librosApi.actualizar(libro.idLibro, datos);
      else await librosApi.crear(datos);
      onGuardado(editando ? 'Libro actualizado.' : 'Libro creado.');
    } catch (e) {
      setError(e.message);
      setGuardando(false);
    }
  }

  return (
    <Modal titulo={editando ? 'Editar libro' : 'Nuevo libro'} abierto onCerrar={onCerrar}>
      <form onSubmit={guardar}>
        <Campo etiqueta="Título" name="titulo" value={form.titulo} onChange={cambiar} error={errores.titulo} autoFocus />
        <Campo etiqueta="Autor" name="autor" value={form.autor} onChange={cambiar} error={errores.autor} />
        <div className="fila-campos">
          <Campo etiqueta="ISBN" name="isbn" value={form.isbn} onChange={cambiar} error={errores.isbn} />
          <Campo
            etiqueta="Ejemplares disponibles"
            name="cantidadDisponible"
            type="number"
            min="0"
            max="10000"
            value={form.cantidadDisponible}
            onChange={cambiar}
            error={errores.cantidadDisponible}
          />
        </div>
        <Alerta>{error}</Alerta>
        <div className="acciones-derecha">
          <Boton type="button" variante="secundario" onClick={onCerrar}>
            Cancelar
          </Boton>
          <Boton type="submit" cargando={guardando}>
            {editando ? 'Guardar cambios' : 'Crear libro'}
          </Boton>
        </div>
      </form>
    </Modal>
  );
}
