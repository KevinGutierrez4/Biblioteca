import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeftRight, BookOpen, CheckCircle2, Clock, Plus, Users } from 'lucide-react';
import { librosApi, prestamosApi, usuariosApi } from '../api/servicios';
import { useAuth } from '../context/AuthContext';
import { useCarga } from '../hooks/useCarga';
import { Boton, Cargando, Encabezado, ErrorCarga, Vacio, EstadoPrestamo } from '../components/ui';
import { formatearFecha } from '../utils/fechas';

export default function Inicio() {
  const { usuario, esAdmin } = useAuth();
  const navigate = useNavigate();

  const { datos, cargando, error, recargar } = useCarga(
    () =>
      Promise.all([
        librosApi.listar(),
        prestamosApi.listar(),
        esAdmin ? usuariosApi.listar() : Promise.resolve(null),
      ]).then(([libros, prestamos, usuarios]) => ({ libros, prestamos, usuarios })),
    [esAdmin]
  );

  if (cargando) return <Cargando />;
  if (error) return <ErrorCarga mensaje={error} onReintentar={recargar} />;

  const { libros, prestamos, usuarios } = datos;
  const activos = prestamos.filter((p) => p.estado === 'Activo').length;
  const ejemplares = libros.reduce((s, l) => s + l.cantidadDisponible, 0);
  const recientes = prestamos.slice(0, 5);

  return (
    <>
      <Encabezado
        titulo={`Hola, ${usuario?.nombre?.split(' ')[0] ?? ''}`}
        subtitulo={esAdmin ? 'Resumen general de la biblioteca' : 'Resumen de tus préstamos'}
      >
        <Boton icono={Plus} onClick={() => navigate('/prestamos/nuevo')}>
          Nuevo préstamo
        </Boton>
      </Encabezado>

      <div className="estadisticas">
        <Estadistica icono={BookOpen} valor={libros.length} texto="Títulos" detalle={`${ejemplares} ejemplares disponibles`} a="/libros" />
        <Estadistica
          icono={Clock}
          valor={activos}
          texto={esAdmin ? 'Préstamos activos' : 'Mis préstamos activos'}
          a="/prestamos"
          tono="advertencia"
        />
        <Estadistica
          icono={CheckCircle2}
          valor={prestamos.length - activos}
          texto="Devueltos"
          a="/prestamos"
          tono="exito"
        />
        {esAdmin ? (
          <Estadistica icono={Users} valor={usuarios.length} texto="Usuarios" a="/usuarios" />
        ) : null}
      </div>

      <section className="tarjeta">
        <div className="tarjeta-cabecera">
          <h2>Préstamos recientes</h2>
          <Link to="/prestamos">Ver todos</Link>
        </div>
        {recientes.length === 0 ? (
          <Vacio icono={ArrowLeftRight} texto="Todavía no hay préstamos." />
        ) : (
          <ul className="lista-simple">
            {recientes.map((p) => (
              <li key={p.idPrestamo} onClick={() => navigate(`/prestamos/${p.idPrestamo}`)}>
                <div>
                  <strong>Préstamo #{p.idPrestamo}</strong>
                  {esAdmin ? <span className="texto-primario"> · {p.usuario.nombre}</span> : null}
                  <p className="texto-suave recortar">{p.detalles.map((d) => d.titulo).join(' · ')}</p>
                </div>
                <div className="lista-derecha">
                  <EstadoPrestamo estado={p.estado} />
                  <span className="texto-pequeno">{formatearFecha(p.fechaPrestamo)}</span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}

function Estadistica({ icono: Icono, valor, texto, detalle, a, tono = 'info' }) {
  return (
    <Link to={a} className={`estadistica tono-${tono}`}>
      <div className="estadistica-icono">
        <Icono size={22} />
      </div>
      <div>
        <div className="estadistica-valor">{valor}</div>
        <div className="estadistica-texto">{texto}</div>
        {detalle ? <div className="texto-pequeno">{detalle}</div> : null}
      </div>
    </Link>
  );
}
