import { Link } from 'react-router-dom';
import { Vacio } from '../components/ui';
import { SearchX } from 'lucide-react';

export default function NoEncontrado() {
  return (
    <div className="tarjeta">
      <Vacio icono={SearchX} texto="Esta página no existe." />
      <p className="texto-centro">
        <Link to="/">Volver al inicio</Link>
      </p>
    </div>
  );
}
