import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Library, UserPlus } from 'lucide-react';
import { authApi } from '../api/servicios';
import { useAuth } from '../context/AuthContext';
import { Alerta, Boton, Campo } from '../components/ui';

const CORREO_VALIDO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Registro() {
  const { iniciarSesion } = useAuth();

  const [form, setForm] = useState({ nombre: '', correo: '', password: '', confirmacion: '' });
  const [errores, setErrores] = useState({});
  const [error, setError] = useState('');
  const [enviando, setEnviando] = useState(false);

  const cambiar = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  function validar() {
    const e = {};
    if (!form.nombre.trim()) e.nombre = 'El nombre es obligatorio.';
    if (!CORREO_VALIDO.test(form.correo.trim())) e.correo = 'Escribe un correo válido.';
    if (form.password.length < 8) e.password = 'Mínimo 8 caracteres.';
    if (form.confirmacion !== form.password) e.confirmacion = 'Las contraseñas no coinciden.';
    setErrores(e);
    return Object.keys(e).length === 0;
  }

  async function enviar(ev) {
    ev.preventDefault();
    setError('');
    if (!validar()) return;
    setEnviando(true);
    try {
      await authApi.registro(form.nombre.trim(), form.correo.trim(), form.password);
      await iniciarSesion(form.correo, form.password); // entra directamente con la cuenta nueva
    } catch (err) {
      setError(err.message);
      setEnviando(false);
    }
  }

  return (
    <div className="pantalla-auth">
      <section className="auth-portada">
        <div className="marca grande">
          <div className="marca-logo">
            <Library size={28} />
          </div>
          <span>Biblioteca</span>
        </div>
        <h2>Crea tu cuenta y solicita préstamos de libros.</h2>
        <p>Las cuentas nuevas se crean con rol Usuario.</p>
      </section>

      <section className="auth-formulario">
        <form onSubmit={enviar} className="tarjeta-auth">
          <h1>Crear cuenta</h1>
          <Campo etiqueta="Nombre" name="nombre" value={form.nombre} onChange={cambiar} error={errores.nombre} />
          <Campo
            etiqueta="Correo"
            name="correo"
            type="email"
            value={form.correo}
            onChange={cambiar}
            error={errores.correo}
          />
          <Campo
            etiqueta="Contraseña"
            name="password"
            type="password"
            value={form.password}
            onChange={cambiar}
            error={errores.password}
          />
          <Campo
            etiqueta="Repite la contraseña"
            name="confirmacion"
            type="password"
            value={form.confirmacion}
            onChange={cambiar}
            error={errores.confirmacion}
          />
          <Alerta>{error}</Alerta>
          <Boton type="submit" icono={UserPlus} cargando={enviando} className="ancho-completo">
            Crear cuenta
          </Boton>
          <p className="texto-centro">
            ¿Ya tienes cuenta? <Link to="/login">Inicia sesión</Link>
          </p>
        </form>
      </section>
    </div>
  );
}
