import { useCallback, useEffect, useState } from 'react';

/**
 * Ejecuta una petición al montar la página (y cuando cambian las dependencias).
 * Devuelve { datos, cargando, error, recargar, setDatos }.
 */
export function useCarga(funcion, dependencias = []) {
  const [estado, setEstado] = useState({ datos: null, cargando: true, error: '' });
  const [version, setVersion] = useState(0);

  useEffect(() => {
    let activo = true;
    funcion()
      .then((datos) => activo && setEstado({ datos, cargando: false, error: '' }))
      .catch((e) => activo && setEstado((s) => ({ ...s, cargando: false, error: e.message })));
    return () => {
      activo = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...dependencias, version]);

  const recargar = useCallback(() => setVersion((v) => v + 1), []);

  const setDatos = useCallback(
    (valor) =>
      setEstado((s) => ({ ...s, datos: typeof valor === 'function' ? valor(s.datos) : valor })),
    []
  );

  return { ...estado, recargar, setDatos };
}

/** Devuelve el valor después de que deja de cambiar durante `ms` milisegundos. */
export function useDebounce(valor, ms = 350) {
  const [diferido, setDiferido] = useState(valor);
  useEffect(() => {
    const t = setTimeout(() => setDiferido(valor), ms);
    return () => clearTimeout(t);
  }, [valor, ms]);
  return diferido;
}
