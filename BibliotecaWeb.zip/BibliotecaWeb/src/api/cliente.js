// URL del backend: archivo .env (VITE_API_URL). Sin barra al final.
export const API_URL = (import.meta.env.VITE_API_URL || 'http://localhost:5120').replace(/\/+$/, '');

let token = null;
let alExpirar = null;

export function establecerToken(nuevoToken) {
  token = nuevoToken;
}

/** Función que se ejecuta cuando el backend responde 401 teniendo token (sesión vencida). */
export function alExpirarSesion(funcion) {
  alExpirar = funcion;
}

export class ApiError extends Error {
  constructor(mensaje, status) {
    super(mensaje);
    this.status = status;
  }
}

/**
 * Hace una petición a BibliotecaAPI: agrega el token JWT, convierte a JSON
 * y traduce los errores del backend a mensajes legibles.
 */
export async function solicitud(ruta, { metodo = 'GET', cuerpo, tiempoLimite = 12000 } = {}) {
  const control = new AbortController();
  const temporizador = setTimeout(() => control.abort(), tiempoLimite);

  const headers = { Accept: 'application/json' };
  if (cuerpo !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;

  let respuesta;
  try {
    respuesta = await fetch(`${API_URL}${ruta}`, {
      method: metodo,
      headers,
      body: cuerpo !== undefined ? JSON.stringify(cuerpo) : undefined,
      signal: control.signal,
    });
  } catch (error) {
    throw new ApiError(
      error?.name === 'AbortError'
        ? 'El servidor no respondió a tiempo.'
        : `No se pudo conectar con el backend (${API_URL}). ¿Está corriendo BibliotecaAPI? ¿Está permitido este origen en CORS?`,
      0
    );
  } finally {
    clearTimeout(temporizador);
  }

  const texto = await respuesta.text();
  let datos = null;
  if (texto) {
    try {
      datos = JSON.parse(texto);
    } catch {
      datos = texto;
    }
  }

  if (respuesta.ok) return datos;

  if (respuesta.status === 401 && token && alExpirar) alExpirar();

  throw new ApiError(extraerMensaje(datos, respuesta.status), respuesta.status);
}

function extraerMensaje(datos, status) {
  if (datos && typeof datos === 'object') {
    if (datos.mensaje) return datos.mensaje; // { mensaje: "..." } de los controladores
    if (datos.errors) {
      // Validaciones de ASP.NET: { errors: { Campo: ["..."] } }
      const mensajes = Object.values(datos.errors).flat();
      if (mensajes.length) return mensajes.join(' ');
    }
    if (datos.title) return datos.title;
  }
  switch (status) {
    case 401:
      return 'Tu sesión expiró. Vuelve a iniciar sesión.';
    case 403:
      return 'No tienes permiso para realizar esta acción.';
    case 404:
      return 'No se encontró el recurso.';
    default:
      return `Error del servidor (HTTP ${status}).`;
  }
}
