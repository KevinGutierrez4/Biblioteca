import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { AvisosProvider } from './components/Avisos';
import { RutaAdmin, RutaPrivada, RutaPublica } from './components/Rutas';
import Layout from './components/Layout';
import Login from './pages/Login';
import Registro from './pages/Registro';
import Inicio from './pages/Inicio';
import Libros from './pages/Libros';
import Prestamos from './pages/Prestamos';
import NuevoPrestamo from './pages/NuevoPrestamo';
import DetallePrestamo from './pages/DetallePrestamo';
import Usuarios from './pages/Usuarios';
import DetalleUsuario from './pages/DetalleUsuario';
import Perfil from './pages/Perfil';
import NoEncontrado from './pages/NoEncontrado';

export default function App() {
  return (
    <AuthProvider>
      <AvisosProvider>
        <BrowserRouter>
          <Routes>
            <Route element={<RutaPublica />}>
              <Route path="/login" element={<Login />} />
              <Route path="/registro" element={<Registro />} />
            </Route>

            <Route element={<RutaPrivada />}>
              <Route element={<Layout />}>
                <Route index element={<Inicio />} />
                <Route path="libros" element={<Libros />} />
                <Route path="prestamos" element={<Prestamos />} />
                <Route path="prestamos/nuevo" element={<NuevoPrestamo />} />
                <Route path="prestamos/:id" element={<DetallePrestamo />} />
                <Route path="perfil" element={<Perfil />} />

                <Route element={<RutaAdmin />}>
                  <Route path="usuarios" element={<Usuarios />} />
                  <Route path="usuarios/:id" element={<DetalleUsuario />} />
                </Route>

                <Route path="*" element={<NoEncontrado />} />
              </Route>
            </Route>
          </Routes>
        </BrowserRouter>
      </AvisosProvider>
    </AuthProvider>
  );
}
