import { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import {
  ArrowLeftRight,
  BookOpen,
  LayoutDashboard,
  Library,
  LogOut,
  Menu,
  UserCircle,
  Users,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAvisos } from './Avisos';

export default function Layout() {
  const { usuario, esAdmin, cerrarSesion } = useAuth();
  const { confirmar } = useAvisos();
  const [menuAbierto, setMenuAbierto] = useState(false);

  const enlaces = [
    { a: '/', texto: 'Inicio', icono: LayoutDashboard, fin: true },
    { a: '/libros', texto: 'Libros', icono: BookOpen },
    { a: '/prestamos', texto: 'Préstamos', icono: ArrowLeftRight },
    ...(esAdmin ? [{ a: '/usuarios', texto: 'Usuarios', icono: Users }] : []),
    { a: '/perfil', texto: 'Mi perfil', icono: UserCircle },
  ];

  async function salir() {
    if (await confirmar('Cerrar sesión', '¿Seguro que quieres salir?', 'Salir')) {
      cerrarSesion({ manual: true }); // RutaPrivada lleva al login
    }
  }

  return (
    <div className="app">
      <aside className={`barra-lateral ${menuAbierto ? 'abierta' : ''}`}>
        <div className="marca">
          <div className="marca-logo">
            <Library size={22} />
          </div>
          <span>Biblioteca</span>
        </div>

        <nav className="menu" onClick={() => setMenuAbierto(false)}>
          {enlaces.map(({ a, texto, icono: Icono, fin }) => (
            <NavLink key={a} to={a} end={fin} className={({ isActive }) => `menu-item ${isActive ? 'activo' : ''}`}>
              <Icono size={19} />
              {texto}
            </NavLink>
          ))}
        </nav>

        <div className="usuario-actual">
          <div className="avatar">{(usuario?.nombre || '?').charAt(0).toUpperCase()}</div>
          <div className="usuario-datos">
            <strong>{usuario?.nombre}</strong>
            <span>{usuario?.rol}</span>
          </div>
          <button className="boton-icono claro" onClick={salir} title="Cerrar sesión" aria-label="Cerrar sesión">
            <LogOut size={18} />
          </button>
        </div>
      </aside>

      {menuAbierto ? <div className="velo" onClick={() => setMenuAbierto(false)} /> : null}

      <div className="principal">
        <header className="barra-movil">
          <button className="boton-icono" onClick={() => setMenuAbierto(true)} aria-label="Abrir menú">
            <Menu size={22} />
          </button>
          <span>Biblioteca</span>
        </header>
        <main className="contenido">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
