import { AlertTriangle, Inbox, Loader2, RefreshCw } from 'lucide-react';

export function Boton({ children, variante = 'primario', icono: Icono, cargando, className = '', ...props }) {
  return (
    <button
      className={`boton boton-${variante} ${className}`}
      disabled={cargando || props.disabled}
      {...props}
    >
      {cargando ? <Loader2 size={18} className="girar" /> : Icono ? <Icono size={18} /> : null}
      {children ? <span>{children}</span> : null}
    </button>
  );
}

export function Campo({ etiqueta, error, id, children, ...props }) {
  const idCampo = id || props.name;
  return (
    <div className="campo">
      {etiqueta ? <label htmlFor={idCampo}>{etiqueta}</label> : null}
      {children ?? <input id={idCampo} className={error ? 'con-error' : ''} {...props} />}
      {error ? <span className="campo-error">{error}</span> : null}
    </div>
  );
}

const TIPOS_INSIGNIA = { exito: 'exito', peligro: 'peligro', advertencia: 'advertencia', info: 'info' };

export function Insignia({ children, tipo = 'info' }) {
  return <span className={`insignia insignia-${TIPOS_INSIGNIA[tipo] ?? 'info'}`}>{children}</span>;
}

export function EstadoPrestamo({ estado }) {
  return <Insignia tipo={estado === 'Activo' ? 'advertencia' : 'exito'}>{estado}</Insignia>;
}

export function Cargando({ texto = 'Cargando…' }) {
  return (
    <div className="estado-centro">
      <Loader2 size={32} className="girar color-primario" />
      <p>{texto}</p>
    </div>
  );
}

export function ErrorCarga({ mensaje, onReintentar }) {
  return (
    <div className="estado-centro">
      <AlertTriangle size={36} className="color-peligro" />
      <h3>No se pudo cargar</h3>
      <p>{mensaje}</p>
      {onReintentar ? (
        <Boton variante="secundario" icono={RefreshCw} onClick={onReintentar}>
          Reintentar
        </Boton>
      ) : null}
    </div>
  );
}

export function Vacio({ texto, icono: Icono = Inbox }) {
  return (
    <div className="vacio">
      <Icono size={36} />
      <p>{texto}</p>
    </div>
  );
}

export function Alerta({ children }) {
  return children ? <div className="alerta-error">{children}</div> : null;
}

/** Cabecera de página: título, subtítulo y acciones a la derecha. */
export function Encabezado({ titulo, subtitulo, children }) {
  return (
    <div className="encabezado">
      <div>
        <h1>{titulo}</h1>
        {subtitulo ? <p>{subtitulo}</p> : null}
      </div>
      {children ? <div className="encabezado-acciones">{children}</div> : null}
    </div>
  );
}

/** Fila de botones tipo "chip" para filtros. opciones: [{ valor, texto }] */
export function Chips({ opciones, valor, onCambiar }) {
  return (
    <div className="chips">
      {opciones.map((op) => (
        <button
          key={String(op.valor)}
          type="button"
          className={`chip ${op.valor === valor ? 'chip-activo' : ''}`}
          onClick={() => onCambiar(op.valor)}
        >
          {op.texto}
        </button>
      ))}
    </div>
  );
}
