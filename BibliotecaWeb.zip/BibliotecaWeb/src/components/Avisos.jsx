import { createContext, useCallback, useContext, useRef, useState } from 'react';
import { CheckCircle2, XCircle } from 'lucide-react';
import Modal from './Modal';
import { Boton } from './ui';

const AvisosContext = createContext(null);

/**
 * Notificaciones (toasts) y diálogo de confirmación propios,
 * en vez de alert() / confirm() del navegador.
 */
export function AvisosProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const [dialogo, setDialogo] = useState(null);
  const resolver = useRef(null);
  const siguienteId = useRef(1);

  const notificar = useCallback((texto, tipo = 'exito') => {
    const id = siguienteId.current++;
    setToasts((t) => [...t, { id, texto, tipo }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3500);
  }, []);

  const confirmar = useCallback((titulo, mensaje, textoAceptar = 'Aceptar', peligro = true) => {
    setDialogo({ titulo, mensaje, textoAceptar, peligro });
    return new Promise((resolve) => {
      resolver.current = resolve;
    });
  }, []);

  const responder = useCallback((valor) => {
    setDialogo(null);
    resolver.current?.(valor);
    resolver.current = null;
  }, []);

  const cancelar = useCallback(() => responder(false), [responder]);

  return (
    <AvisosContext.Provider value={{ notificar, confirmar }}>
      {children}

      <Modal titulo={dialogo?.titulo} abierto={!!dialogo} onCerrar={cancelar} ancho={420}>
        <p className="dialogo-texto">{dialogo?.mensaje}</p>
        <div className="acciones-derecha">
          <Boton variante="secundario" onClick={cancelar}>
            Cancelar
          </Boton>
          <Boton variante={dialogo?.peligro ? 'peligro-lleno' : 'primario'} onClick={() => responder(true)}>
            {dialogo?.textoAceptar}
          </Boton>
        </div>
      </Modal>

      <div className="toasts" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.tipo}`}>
            {t.tipo === 'exito' ? <CheckCircle2 size={18} /> : <XCircle size={18} />}
            <span>{t.texto}</span>
          </div>
        ))}
      </div>
    </AvisosContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAvisos() {
  return useContext(AvisosContext);
}
