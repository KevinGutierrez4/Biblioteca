import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

/**
 * Solo deja pasar si hay sesión; si no, manda al login.
 * Si la sesión venció o se abrió un enlace directo, recuerda la página para volver después del login.
 * Si el usuario cerró sesión a propósito, no (el siguiente usuario empieza en Inicio).
 */
export function RutaPrivada() {
  const { sesion, salidaManual } = useAuth();
  const ubicacion = useLocation();
  if (!sesion) {
    const estado = salidaManual ? undefined : { desde: ubicacion.pathname + ubicacion.search };
    return <Navigate to="/login" replace state={estado} />;
  }
  return <Outlet />;
}

/** Solo para el Administrador. La seguridad real la aplica el backend con [Authorize(Roles)]. */
export function RutaAdmin() {
  const { esAdmin } = useAuth();
  if (!esAdmin) return <Navigate to="/" replace />;
  return <Outlet />;
}

/** Login y registro: si ya hay sesión, vuelve a la página que se quería abrir (o al inicio). */
export function RutaPublica() {
  const { sesion } = useAuth();
  const ubicacion = useLocation();
  if (sesion) return <Navigate to={ubicacion.state?.desde || '/'} replace />;
  return <Outlet />;
}
