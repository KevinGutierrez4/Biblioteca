import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { authApi } from '../api/servicios';
import { alExpirarSesion, establecerToken } from '../api/cliente';
import { parsearFecha } from '../utils/fechas';

const CLAVE_SESION = 'biblioteca_sesion';
const AuthContext = createContext(null);

/** Lee la sesión guardada en el navegador si el token no venció. */
function leerSesionGuardada() {
  try {
    const datos = JSON.parse(localStorage.getItem(CLAVE_SESION));
    const vence = parsearFecha(datos?.expiracion);
    if (datos?.token && vence && vence > new Date()) {
      establecerToken(datos.token);
      return datos;
    }
  } catch {
    // Datos corruptos: se ignoran.
  }
  localStorage.removeItem(CLAVE_SESION);
  return null;
}

export function AuthProvider({ children }) {
  const [sesion, setSesion] = useState(leerSesionGuardada); // { token, expiracion, usuario }
  // true si el usuario pulsó "Cerrar sesión"; false si la sesión venció (401).
  const [salidaManual, setSalidaManual] = useState(false);

  const cerrarSesion = useCallback(({ manual = false } = {}) => {
    establecerToken(null);
    localStorage.removeItem(CLAVE_SESION);
    setSalidaManual(manual);
    setSesion(null);
  }, []);

  // Si el backend responde 401 (token vencido) se cierra la sesión automáticamente.
  useEffect(() => {
    alExpirarSesion(() => cerrarSesion({ manual: false }));
  }, [cerrarSesion]);

  const iniciarSesion = useCallback(async (correo, password) => {
    const r = await authApi.login(correo.trim(), password);
    const nueva = { token: r.token, expiracion: r.expiracion, usuario: r.usuario };
    establecerToken(nueva.token);
    localStorage.setItem(CLAVE_SESION, JSON.stringify(nueva));
    setSalidaManual(false);
    setSesion(nueva);
  }, []);

  /** Actualiza nombre/correo/rol guardados (por ejemplo, después de GET /api/usuarios/me). */
  const actualizarUsuario = useCallback((usuario) => {
    setSesion((actual) => {
      if (!actual) return actual;
      const nueva = { ...actual, usuario: { ...actual.usuario, ...usuario } };
      localStorage.setItem(CLAVE_SESION, JSON.stringify(nueva));
      return nueva;
    });
  }, []);

  const valor = useMemo(
    () => ({
      sesion,
      usuario: sesion?.usuario ?? null,
      esAdmin: sesion?.usuario?.rol === 'Administrador',
      salidaManual,
      iniciarSesion,
      cerrarSesion,
      actualizarUsuario,
    }),
    [sesion, salidaManual, iniciarSesion, cerrarSesion, actualizarUsuario]
  );

  return <AuthContext.Provider value={valor}>{children}</AuthContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const contexto = useContext(AuthContext);
  if (!contexto) throw new Error('useAuth debe usarse dentro de AuthProvider');
  return contexto;
}
