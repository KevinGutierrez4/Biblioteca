# Biblioteca Móvil (React Native + Expo)

App Android que consume **BibliotecaAPI** (ASP.NET Core Web API + JWT).
Hecha con Expo SDK 58, Expo Router y JavaScript.

## Funcionalidades

**Todos los usuarios:** registrarse, iniciar sesión (JWT guardado cifrado con SecureStore), ver y buscar libros,
pedir préstamos de **uno o varios libros**, ver sus préstamos y su perfil.

**Administrador – CRUD completo:**

| Entidad | Crear | Ver | Editar | Eliminar |
|---|---|---|---|---|
| Libros | Botón *Nuevo libro* | Lista con búsqueda + detalle | *Editar* (título, autor, ISBN, stock) | *Eliminar* (bloqueado si tiene historial) |
| Usuarios | Botón *Nuevo usuario* (con rol) | Lista con búsqueda + detalle con su historial de préstamos | Nombre, correo y rol | *Eliminar* (bloqueado si tiene préstamos o si eres tú) |
| Préstamos | *Nuevo préstamo* a nombre de cualquier usuario | Todos, filtrando por estado y por usuario | *Registrar devolución* / *Reactivar* | *Eliminar* (devuelve el stock si estaba activo) |

> Crear usuario usa `POST /api/auth/register` y, si el rol es Administrador, `PUT /api/usuarios/{id}`.
> No requiere cambios en el backend.

- La sesión se mantiene al cerrar la app y se cierra sola cuando el token vence (HTTP 401).
- La dirección del backend se cambia desde la app (pantalla **Servidor**) sin recompilar.

## Puesta en marcha

```bash
npm install
npx expo start
```
Escanea el QR con **Expo Go** (Android). Admin inicial del backend: `admin@biblioteca.com` / `Admin12345`.

## Conectar el celular con BibliotecaAPI

Resumen de tu guía, adaptado a este backend (puerto **5120**):

1. **Misma red**: activa el hotspot del celular y conecta la PC a esa red (o usa el mismo Wi-Fi).
   Marca la red como **Privada** en Windows.
2. **IP de la PC**: en CMD, `ipconfig` → IPv4 del adaptador Wi-Fi (ignora VirtualBox `192.168.56.1`).
3. **Backend**: en Visual Studio elige el perfil **http-celular** y ejecútalo.
   Ese perfil escucha en `http://0.0.0.0:5120` (todas las interfaces) y en desarrollo no redirige a HTTPS.
4. **Firewall** (CMD como administrador, una sola vez):
   ```
   netsh advfirewall firewall add rule name="Expo Metro 8081" dir=in action=allow protocol=TCP localport=8081
   netsh advfirewall firewall add rule name="BibliotecaAPI 5120" dir=in action=allow protocol=TCP localport=5120
   ```
   Para quitarlas al terminar:
   ```
   netsh advfirewall firewall delete rule name="Expo Metro 8081"
   netsh advfirewall firewall delete rule name="BibliotecaAPI 5120"
   ```
5. **Prueba en el navegador del celular**: `http://TU-IP:5120/api/libros`.
   Si responde **401** (página en blanco o error de autorización), la conexión funciona: falta el token, que pone la app.
6. **En la app**: en el login toca **Cambiar** (abajo, junto a "Servidor") → escribe `http://TU-IP:5120` → **Probar** → **Guardar**.
   También puedes ponerla en `.env` (`EXPO_PUBLIC_API_URL=http://TU-IP:5120`) y reiniciar con `npx expo start -c`.

| Síntoma | Solución |
|---|---|
| "No se pudo conectar con el backend" | IP incorrecta, redes distintas o el backend no está corriendo con el perfil **http-celular** |
| "Tiempo agotado" | Regla de firewall del puerto 5120 y red **Privada** |
| Expo Go se queda cargando | Regla del puerto 8081, o `npx expo start --tunnel` |
| El QR muestra `exp://192.168.56.1:8081` | `set REACT_NATIVE_PACKAGER_HOSTNAME=TU-IP` y `npx expo start -c` |
| Funciona en casa pero no en la universidad | La red aísla dispositivos: usa el hotspot |
| Emulador de Android | Usa `http://10.0.2.2:5120` con el perfil **http** |
| "Project is incompatible with this version of Expo Go" | Expo Go se actualizó a otro SDK: `npx expo install expo@latest --fix` |

## Estructura

```
src/
  app/                    Pantallas (Expo Router: cada archivo es una ruta)
    _layout.js            Navegación raíz + rutas protegidas por sesión
    login.js, registro.js, servidor.js
    (tabs)/               Pestañas: libros, prestamos, usuarios (solo admin), perfil
    libro/[id].js         Detalle de libro
    libro-form.js         Crear / editar libro (admin)
    nuevo-prestamo.js     Préstamo de varios libros (relación N:M)
    prestamo/[id].js      Detalle, devolución, eliminar
    usuario/nuevo.js      Crear usuario con rol (admin)
    usuario/[id].js       Editar usuario, rol, historial de préstamos (admin)
  api/
    config.js             Dirección del servidor (.env o guardada en el celular)
    cliente.js            fetch + token JWT + mensajes de error del backend
    servicios.js          Un método por endpoint de BibliotecaAPI
  context/AuthContext.js  Sesión: login, logout, rol, vencimiento del token
  components/             Botón, Campo, Tarjeta, Insignia, Selector, estados de carga/error
```
