import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { authApi } from '../api/servicios';
import { alExpirarSesion, establecerToken } from '../api/cliente';
import { cargarServidor } from '../api/config';
import { borrarSeguro, guardarSeguro, leerSeguro } from '../utils/almacenamiento';
import { parsearFecha } from '../utils/fechas';

const CLAVE_SESION = 'sesion';
const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [sesion, setSesion] = useState(null); // { token, expiracion, usuario }
  const [cargando, setCargando] = useState(true);

  const cerrarSesion = useCallback(async () => {
    establecerToken(null);
    setSesion(null);
    await borrarSeguro(CLAVE_SESION);
  }, []);

  // Al abrir la app: carga la dirección del servidor y la sesión guardada (si no venció).
  useEffect(() => {
    (async () => {
      await cargarServidor();
      const guardada = await leerSeguro(CLAVE_SESION);
      if (guardada) {
        try {
          const datos = JSON.parse(guardada);
          const vence = parsearFecha(datos.expiracion);
          if (datos.token && vence && vence > new Date()) {
            establecerToken(datos.token);
            setSesion(datos);
          } else {
            await borrarSeguro(CLAVE_SESION);
          }
        } catch {
          await borrarSeguro(CLAVE_SESION);
        }
      }
      setCargando(false);
    })();
  }, []);

  // Si el backend responde 401 (token vencido), se cierra la sesión automáticamente.
  useEffect(() => {
    alExpirarSesion(() => {
      cerrarSesion();
    });
  }, [cerrarSesion]);

  const iniciarSesion = useCallback(async (correo, password) => {
    const respuesta = await authApi.login(correo.trim(), password);
    const nueva = {
      token: respuesta.token,
      expiracion: respuesta.expiracion,
      usuario: respuesta.usuario,
    };
    establecerToken(nueva.token);
    await guardarSeguro(CLAVE_SESION, JSON.stringify(nueva));
    setSesion(nueva);
  }, []);

  const valor = useMemo(
    () => ({
      sesion,
      usuario: sesion?.usuario ?? null,
      esAdmin: sesion?.usuario?.rol === 'Administrador',
      cargando,
      iniciarSesion,
      cerrarSesion,
    }),
    [sesion, cargando, iniciarSesion, cerrarSesion],
  );

  return <AuthContext.Provider value={valor}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const contexto = useContext(AuthContext);
  if (!contexto) throw new Error('useAuth debe usarse dentro de AuthProvider');
  return contexto;
}
