import { solicitud } from './cliente';

function consulta(parametros) {
  const partes = Object.entries(parametros)
    .filter(([, valor]) => valor !== undefined && valor !== null && valor !== '')
    .map(([clave, valor]) => `${clave}=${encodeURIComponent(valor)}`);
  return partes.length ? `?${partes.join('&')}` : '';
}

// ---------- Autenticación ----------
export const authApi = {
  login: (correo, password) =>
    solicitud('/api/auth/login', { metodo: 'POST', cuerpo: { correo, password } }),

  registro: (nombre, correo, password) =>
    solicitud('/api/auth/register', { metodo: 'POST', cuerpo: { nombre, correo, password } }),
};

// ---------- Libros ----------
export const librosApi = {
  listar: (buscar) => solicitud(`/api/libros${consulta({ buscar })}`),
  obtener: (id) => solicitud(`/api/libros/${id}`),
  crear: (libro) => solicitud('/api/libros', { metodo: 'POST', cuerpo: libro }),
  actualizar: (id, libro) => solicitud(`/api/libros/${id}`, { metodo: 'PUT', cuerpo: libro }),
  eliminar: (id) => solicitud(`/api/libros/${id}`, { metodo: 'DELETE' }),
};

// ---------- Préstamos ----------
export const prestamosApi = {
  listar: ({ estado, idUsuario } = {}) =>
    solicitud(`/api/prestamos${consulta({ estado, idUsuario })}`),
  obtener: (id) => solicitud(`/api/prestamos/${id}`),
  /** detalles: [{ idLibro, cantidad }]. idUsuario solo lo usa el Administrador. */
  crear: (detalles, idUsuario) =>
    solicitud('/api/prestamos', { metodo: 'POST', cuerpo: { idUsuario, detalles } }),
  cambiarEstado: (id, estado) =>
    solicitud(`/api/prestamos/${id}`, { metodo: 'PUT', cuerpo: { estado } }),
  eliminar: (id) => solicitud(`/api/prestamos/${id}`, { metodo: 'DELETE' }),
};

// ---------- Usuarios ----------
export const usuariosApi = {
  yo: () => solicitud('/api/usuarios/me'),
  listar: () => solicitud('/api/usuarios'),
  obtener: (id) => solicitud(`/api/usuarios/${id}`),
  actualizar: (id, usuario) => solicitud(`/api/usuarios/${id}`, { metodo: 'PUT', cuerpo: usuario }),
  eliminar: (id) => solicitud(`/api/usuarios/${id}`, { metodo: 'DELETE' }),
};
