import AsyncStorage from '@react-native-async-storage/async-storage';

const CLAVE_SERVIDOR = 'servidor_api';

// Valor inicial: variable del archivo .env, o el emulador de Android si no existe.
export const SERVIDOR_POR_DEFECTO = normalizarServidor(
  process.env.EXPO_PUBLIC_API_URL || 'http://10.0.2.2:5120',
);

let servidorActual = SERVIDOR_POR_DEFECTO;

/** "192.168.1.25:5120/" -> "http://192.168.1.25:5120" */
export function normalizarServidor(texto) {
  let url = (texto || '').trim();
  if (!url) return '';
  if (!/^https?:\/\//i.test(url)) url = `http://${url}`;
  return url.replace(/\/+$/, '');
}

export function obtenerServidor() {
  return servidorActual;
}

/** Lee la dirección guardada en el celular (pantalla Servidor). */
export async function cargarServidor() {
  try {
    const guardado = await AsyncStorage.getItem(CLAVE_SERVIDOR);
    if (guardado) servidorActual = guardado;
  } catch {
    // Si falla el almacenamiento se usa el valor por defecto.
  }
  return servidorActual;
}

export async function guardarServidor(url) {
  servidorActual = normalizarServidor(url);
  try {
    await AsyncStorage.setItem(CLAVE_SERVIDOR, servidorActual);
  } catch {
    // Se mantiene en memoria aunque no se pueda guardar.
  }
  return servidorActual;
}

export async function restablecerServidor() {
  servidorActual = SERVIDOR_POR_DEFECTO;
  try {
    await AsyncStorage.removeItem(CLAVE_SERVIDOR);
  } catch {
    // Sin acción.
  }
  return servidorActual;
}

/**
 * Comprueba si hay un backend en esa dirección.
 * Cualquier respuesta HTTP (incluso 401) significa que la conexión funciona.
 */
export async function probarServidor(url) {
  const base = normalizarServidor(url);
  if (!base) return { ok: false, mensaje: 'Escribe una dirección.' };

  const control = new AbortController();
  const temporizador = setTimeout(() => control.abort(), 6000);

  try {
    const respuesta = await fetch(`${base}/api/libros`, { signal: control.signal });
    if (respuesta.status === 401 || respuesta.ok) {
      return { ok: true, mensaje: `Conectado con BibliotecaAPI (HTTP ${respuesta.status}).` };
    }
    return {
      ok: false,
      mensaje: `El servidor respondió HTTP ${respuesta.status}. ¿Es la dirección de BibliotecaAPI?`,
    };
  } catch (error) {
    return {
      ok: false,
      mensaje:
        error?.name === 'AbortError'
          ? 'Tiempo agotado. Revisa la IP, que estén en la misma red y el Firewall de Windows.'
          : 'Sin respuesta. Revisa la IP, el puerto y que el backend esté corriendo.',
    };
  } finally {
    clearTimeout(temporizador);
  }
}
