import { obtenerServidor } from './config';

let token = null;
let alExpirar = null;

export function establecerToken(nuevoToken) {
  token = nuevoToken;
}

/** Función que se ejecuta cuando el backend responde 401 con un token (sesión vencida). */
export function alExpirarSesion(funcion) {
  alExpirar = funcion;
}

export class ApiError extends Error {
  constructor(mensaje, status) {
    super(mensaje);
    this.status = status;
  }
}

/**
 * Hace una petición a BibliotecaAPI.
 * Agrega el token JWT, convierte a JSON y traduce los errores a mensajes legibles.
 */
export async function solicitud(ruta, { metodo = 'GET', cuerpo, tiempoLimite = 12000 } = {}) {
  const control = new AbortController();
  const temporizador = setTimeout(() => control.abort(), tiempoLimite);

  const headers = { Accept: 'application/json' };
  if (cuerpo !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;

  let respuesta;
  try {
    respuesta = await fetch(`${obtenerServidor()}${ruta}`, {
      method: metodo,
      headers,
      body: cuerpo !== undefined ? JSON.stringify(cuerpo) : undefined,
      signal: control.signal,
    });
  } catch (error) {
    throw new ApiError(
      error?.name === 'AbortError'
        ? 'El servidor no respondió a tiempo. Revisa la IP y que el backend esté corriendo.'
        : 'No se pudo conectar con el backend. Revisa la dirección del servidor y que estés en la misma red.',
      0,
    );
  } finally {
    clearTimeout(temporizador);
  }

  const texto = await respuesta.text();
  let datos = null;
  if (texto) {
    try {
      datos = JSON.parse(texto);
    } catch {
      datos = texto;
    }
  }

  if (respuesta.ok) return datos;

  if (respuesta.status === 401 && token && alExpirar) alExpirar();

  throw new ApiError(extraerMensaje(datos, respuesta.status), respuesta.status);
}

function extraerMensaje(datos, status) {
  if (datos && typeof datos === 'object') {
    // Errores propios del backend: { mensaje: "..." }
    if (datos.mensaje) return datos.mensaje;

    // Errores de validación de ASP.NET: { errors: { Campo: ["..."] } }
    if (datos.errors) {
      const mensajes = Object.values(datos.errors).flat();
      if (mensajes.length) return mensajes.join('\n');
    }
    if (datos.title) return datos.title;
  }

  switch (status) {
    case 401:
      return 'Tu sesión expiró. Vuelve a iniciar sesión.';
    case 403:
      return 'No tienes permiso para realizar esta acción.';
    case 404:
      return 'No se encontró el recurso.';
    default:
      return `Error del servidor (HTTP ${status}).`;
  }
}
