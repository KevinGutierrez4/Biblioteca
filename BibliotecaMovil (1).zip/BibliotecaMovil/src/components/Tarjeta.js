import { Pressable, StyleSheet, View } from 'react-native';
import { colores, radio } from '../theme';

export default function Tarjeta({ children, onPress, estilo }) {
  if (!onPress) return <View style={[styles.tarjeta, estilo]}>{children}</View>;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.tarjeta, pressed && styles.presionada, estilo]}
    >
      {children}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  tarjeta: {
    backgroundColor: colores.tarjeta,
    borderRadius: radio,
    borderWidth: 1,
    borderColor: colores.borde,
    padding: 14,
    marginBottom: 10,
  },
  presionada: { backgroundColor: colores.primarioSuave },
});
