import { StyleSheet, Text, View } from 'react-native';
import { colores } from '../theme';

const TIPOS = {
  exito: { fondo: colores.exitoSuave, texto: colores.exito },
  peligro: { fondo: colores.peligroSuave, texto: colores.peligro },
  advertencia: { fondo: colores.advertenciaSuave, texto: colores.advertencia },
  info: { fondo: colores.primarioSuave, texto: colores.primario },
};

export default function Insignia({ texto, tipo = 'info' }) {
  const t = TIPOS[tipo] ?? TIPOS.info;
  return (
    <View style={[styles.insignia, { backgroundColor: t.fondo }]}>
      <Text style={[styles.texto, { color: t.texto }]}>{texto}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  insignia: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  texto: { fontSize: 12, fontWeight: '700' },
});
