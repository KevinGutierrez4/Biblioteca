import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Boton from './Boton';
import { colores } from '../theme';

export function Cargando({ texto = 'Cargando…' }) {
  return (
    <View style={styles.centro}>
      <ActivityIndicator size="large" color={colores.primario} />
      <Text style={styles.textoSuave}>{texto}</Text>
    </View>
  );
}

export function ErrorCarga({ mensaje, onReintentar }) {
  return (
    <View style={styles.centro}>
      <Ionicons name="cloud-offline-outline" size={48} color={colores.peligro} />
      <Text style={styles.titulo}>No se pudo cargar</Text>
      <Text style={styles.textoSuave}>{mensaje}</Text>
      {onReintentar ? (
        <Boton titulo="Reintentar" icono="refresh" onPress={onReintentar} estilo={styles.boton} />
      ) : null}
    </View>
  );
}

export function Vacio({ icono = 'file-tray-outline', texto }) {
  return (
    <View style={styles.vacio}>
      <Ionicons name={icono} size={44} color={colores.textoSuave} />
      <Text style={styles.textoSuave}>{texto}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  centro: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    gap: 10,
    backgroundColor: colores.fondo,
  },
  vacio: { alignItems: 'center', paddingVertical: 48, gap: 10 },
  titulo: { fontSize: 18, fontWeight: '700', color: colores.texto },
  textoSuave: { fontSize: 15, color: colores.textoSuave, textAlign: 'center' },
  boton: { marginTop: 8, minWidth: 160 },
});
