import { Pressable, ScrollView, StyleSheet, Text } from 'react-native';
import { colores } from '../theme';

/** Fila de opciones tipo "chip". opciones: [{ valor, texto }] */
export default function Selector({ opciones, valor, onCambiar, estilo }) {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={[styles.fila, estilo]}
    >
      {opciones.map((op) => {
        const activo = op.valor === valor;
        return (
          <Pressable
            key={String(op.valor)}
            onPress={() => onCambiar(op.valor)}
            style={[styles.chip, activo && styles.chipActivo]}
          >
            <Text style={[styles.texto, activo && styles.textoActivo]}>{op.texto}</Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  fila: { gap: 8, paddingVertical: 4 },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: colores.borde,
    backgroundColor: colores.tarjeta,
  },
  chipActivo: { backgroundColor: colores.primario, borderColor: colores.primario },
  texto: { color: colores.texto, fontWeight: '600' },
  textoActivo: { color: colores.blanco },
});
