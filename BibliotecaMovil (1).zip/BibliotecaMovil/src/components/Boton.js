import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colores, radio } from '../theme';

const VARIANTES = {
  primario: { fondo: colores.primario, texto: colores.blanco, borde: colores.primario },
  secundario: { fondo: colores.tarjeta, texto: colores.primario, borde: colores.primario },
  peligro: { fondo: colores.tarjeta, texto: colores.peligro, borde: colores.peligro },
  exito: { fondo: colores.exito, texto: colores.blanco, borde: colores.exito },
};

export default function Boton({
  titulo,
  onPress,
  variante = 'primario',
  icono,
  cargando = false,
  deshabilitado = false,
  estilo,
}) {
  const v = VARIANTES[variante] ?? VARIANTES.primario;
  const inactivo = deshabilitado || cargando;

  return (
    <Pressable
      onPress={onPress}
      disabled={inactivo}
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.boton,
        { backgroundColor: v.fondo, borderColor: v.borde },
        pressed && styles.presionado,
        inactivo && styles.inactivo,
        estilo,
      ]}
    >
      {cargando ? (
        <ActivityIndicator color={v.texto} />
      ) : (
        <View style={styles.contenido}>
          {icono ? <Ionicons name={icono} size={18} color={v.texto} /> : null}
          <Text style={[styles.texto, { color: v.texto }]}>{titulo}</Text>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  boton: {
    minHeight: 48,
    borderRadius: radio,
    borderWidth: 1.5,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  contenido: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  texto: { fontSize: 16, fontWeight: '600' },
  presionado: { opacity: 0.8 },
  inactivo: { opacity: 0.5 },
});
