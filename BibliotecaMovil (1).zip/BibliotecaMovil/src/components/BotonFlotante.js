import { Pressable, StyleSheet, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colores } from '../theme';

export default function BotonFlotante({ icono = 'add', texto, onPress }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={texto}
      style={({ pressed }) => [styles.boton, pressed && { opacity: 0.85 }]}
    >
      <Ionicons name={icono} size={22} color={colores.blanco} />
      {texto ? <Text style={styles.texto}>{texto}</Text> : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  boton: {
    position: 'absolute',
    right: 16,
    bottom: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colores.primario,
    paddingHorizontal: 18,
    height: 52,
    borderRadius: 26,
    elevation: 4,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },
  texto: { color: colores.blanco, fontSize: 15, fontWeight: '700' },
});
