export const colores = {
  primario: '#2457A6',
  primarioOscuro: '#1A3F7A',
  primarioSuave: '#E7EEF9',
  fondo: '#F3F5F9',
  tarjeta: '#FFFFFF',
  texto: '#1B2430',
  textoSuave: '#5B6675',
  borde: '#DDE2EA',
  exito: '#1E8E5A',
  exitoSuave: '#E3F4EC',
  peligro: '#C8372D',
  peligroSuave: '#FBE9E7',
  advertencia: '#9A6400',
  advertenciaSuave: '#FDF3DC',
  blanco: '#FFFFFF',
};

export const espacio = { xs: 4, s: 8, m: 12, l: 16, xl: 24 };

export const radio = 12;
