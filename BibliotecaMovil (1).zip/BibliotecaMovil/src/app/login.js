import { useCallback, useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Boton from '../components/Boton';
import Campo from '../components/Campo';
import { useAuth } from '../context/AuthContext';
import { obtenerServidor } from '../api/config';
import { colores } from '../theme';

export default function Login() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { iniciarSesion } = useAuth();

  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [verPassword, setVerPassword] = useState(false);
  const [error, setError] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [servidor, setServidor] = useState(obtenerServidor());

  // Actualiza la dirección mostrada al volver de la pantalla Servidor.
  useFocusEffect(
    useCallback(() => {
      setServidor(obtenerServidor());
    }, []),
  );

  async function ingresar() {
    setError('');
    if (!correo.trim() || !password) {
      setError('Escribe tu correo y contraseña.');
      return;
    }
    setEnviando(true);
    try {
      await iniciarSesion(correo, password);
      // Al cambiar la sesión, la navegación lleva automáticamente a la app.
    } catch (e) {
      setError(e.message);
      setEnviando(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.pantalla}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={[styles.contenido, { paddingTop: insets.top + 40 }]}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.encabezado}>
          <View style={styles.logo}>
            <Ionicons name="library" size={40} color={colores.blanco} />
          </View>
          <Text style={styles.titulo}>Biblioteca</Text>
          <Text style={styles.subtitulo}>Inicia sesión para ver libros y préstamos</Text>
        </View>

        <View style={styles.formulario}>
          <Campo
            etiqueta="Correo"
            value={correo}
            onChangeText={setCorreo}
            placeholder="admin@biblioteca.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="email"
          />
          <Campo
            etiqueta="Contraseña"
            value={password}
            onChangeText={setPassword}
            placeholder="••••••••"
            secureTextEntry={!verPassword}
            autoCapitalize="none"
            onSubmitEditing={ingresar}
          />
          <Pressable onPress={() => setVerPassword((v) => !v)} style={styles.verPassword}>
            <Ionicons
              name={verPassword ? 'eye-off-outline' : 'eye-outline'}
              size={18}
              color={colores.primario}
            />
            <Text style={styles.enlace}>
              {verPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'}
            </Text>
          </Pressable>

          {error ? <Text style={styles.error}>{error}</Text> : null}

          <Boton titulo="Ingresar" icono="log-in-outline" onPress={ingresar} cargando={enviando} />

          <Pressable onPress={() => router.push('/registro')} style={styles.filaEnlace}>
            <Text style={styles.textoSuave}>¿No tienes cuenta? </Text>
            <Text style={styles.enlace}>Regístrate</Text>
          </Pressable>
        </View>

        <Pressable onPress={() => router.push('/servidor')} style={styles.servidor}>
          <Ionicons name="server-outline" size={18} color={colores.textoSuave} />
          <Text style={styles.servidorTexto} numberOfLines={1}>
            Servidor: {servidor}
          </Text>
          <Text style={styles.enlace}>Cambiar</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  pantalla: { flex: 1, backgroundColor: colores.fondo },
  contenido: { padding: 24, flexGrow: 1 },
  encabezado: { alignItems: 'center', marginBottom: 28 },
  logo: {
    width: 76,
    height: 76,
    borderRadius: 22,
    backgroundColor: colores.primario,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },
  titulo: { fontSize: 28, fontWeight: '800', color: colores.texto },
  subtitulo: { fontSize: 15, color: colores.textoSuave, marginTop: 4 },
  formulario: {
    backgroundColor: colores.tarjeta,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: colores.borde,
  },
  verPassword: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 16 },
  error: {
    color: colores.peligro,
    backgroundColor: colores.peligroSuave,
    padding: 10,
    borderRadius: 8,
    marginBottom: 14,
  },
  filaEnlace: { flexDirection: 'row', justifyContent: 'center', marginTop: 18 },
  textoSuave: { color: colores.textoSuave, fontSize: 15 },
  enlace: { color: colores.primario, fontSize: 15, fontWeight: '700' },
  servidor: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 'auto',
    paddingTop: 24,
    paddingBottom: 8,
    justifyContent: 'center',
  },
  servidorTexto: { color: colores.textoSuave, fontSize: 13, flexShrink: 1 },
});
