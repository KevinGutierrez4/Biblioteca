import { useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Boton from '../components/Boton';
import Campo from '../components/Campo';
import {
  SERVIDOR_POR_DEFECTO,
  guardarServidor,
  normalizarServidor,
  obtenerServidor,
  probarServidor,
  restablecerServidor,
} from '../api/config';
import { useAuth } from '../context/AuthContext';
import { colores } from '../theme';

export default function Servidor() {
  const router = useRouter();
  const { sesion, cerrarSesion } = useAuth();

  const [url, setUrl] = useState(obtenerServidor());
  const [resultado, setResultado] = useState(null); // { ok, mensaje }
  const [probando, setProbando] = useState(false);

  async function probar() {
    setProbando(true);
    setResultado(null);
    setResultado(await probarServidor(url));
    setProbando(false);
  }

  async function guardar() {
    const anterior = obtenerServidor();
    const nuevo = await guardarServidor(url);
    // El token pertenece al servidor anterior: si cambia la dirección, se cierra la sesión.
    if (sesion && nuevo !== anterior) await cerrarSesion();
    router.back();
  }

  async function restablecer() {
    setUrl(await restablecerServidor());
    setResultado(null);
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido} keyboardShouldPersistTaps="handled">
      <Campo
        etiqueta="Dirección de BibliotecaAPI"
        value={url}
        onChangeText={(t) => {
          setUrl(t);
          setResultado(null);
        }}
        placeholder="http://192.168.1.25:5120"
        autoCapitalize="none"
        autoCorrect={false}
        keyboardType="url"
      />
      <Text style={styles.ayuda}>Se usará: {normalizarServidor(url) || '—'}</Text>

      {resultado ? (
        <View style={[styles.resultado, resultado.ok ? styles.ok : styles.fallo]}>
          <Ionicons
            name={resultado.ok ? 'checkmark-circle' : 'alert-circle'}
            size={20}
            color={resultado.ok ? colores.exito : colores.peligro}
          />
          <Text
            style={[
              styles.resultadoTexto,
              { color: resultado.ok ? colores.exito : colores.peligro },
            ]}
          >
            {resultado.mensaje}
          </Text>
        </View>
      ) : null}

      <View style={styles.botones}>
        <Boton
          titulo="Probar"
          icono="pulse-outline"
          variante="secundario"
          onPress={probar}
          cargando={probando}
        />
        <Boton titulo="Guardar" icono="save-outline" onPress={guardar} />
        <Boton titulo="Restablecer valor del .env" variante="secundario" onPress={restablecer} />
      </View>

      <View style={styles.guia}>
        <Text style={styles.guiaTitulo}>¿Qué dirección escribo?</Text>
        <Text style={styles.guiaTexto}>
          • Celular físico: la IPv4 de tu PC (comando <Text style={styles.code}>ipconfig</Text>) y
          el puerto 5120. Ej.: http://192.168.43.100:5120{'\n'}• Emulador de Android:
          http://10.0.2.2:5120{'\n'}• En Visual Studio ejecuta el perfil{' '}
          <Text style={styles.code}>http-celular</Text> para que el backend acepte conexiones del
          celular.{'\n'}• Valor del .env: {SERVIDOR_POR_DEFECTO}
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20 },
  ayuda: { color: colores.textoSuave, fontSize: 13, marginTop: -6, marginBottom: 14 },
  resultado: {
    flexDirection: 'row',
    gap: 8,
    padding: 12,
    borderRadius: 10,
    marginBottom: 14,
    alignItems: 'flex-start',
  },
  ok: { backgroundColor: colores.exitoSuave },
  fallo: { backgroundColor: colores.peligroSuave },
  resultadoTexto: { flex: 1, fontSize: 14 },
  botones: { gap: 10 },
  guia: {
    marginTop: 24,
    padding: 16,
    borderRadius: 12,
    backgroundColor: colores.primarioSuave,
  },
  guiaTitulo: { fontWeight: '700', color: colores.texto, marginBottom: 6, fontSize: 15 },
  guiaTexto: { color: colores.texto, lineHeight: 22, fontSize: 14 },
  code: { fontFamily: 'monospace', fontWeight: '700' },
});
