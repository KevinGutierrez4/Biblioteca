import { useCallback, useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import Boton from '../../components/Boton';
import Campo from '../../components/Campo';
import Selector from '../../components/Selector';
import { Cargando, ErrorCarga } from '../../components/Estados';
import Tarjeta from '../../components/Tarjeta';
import Insignia from '../../components/Insignia';
import { formatearFecha } from '../../utils/fechas';
import { prestamosApi, usuariosApi } from '../../api/servicios';
import { useAuth } from '../../context/AuthContext';
import { avisar, confirmar } from '../../utils/confirmar';
import { colores } from '../../theme';

const ROLES = [
  { valor: 'Usuario', texto: 'Usuario' },
  { valor: 'Administrador', texto: 'Administrador' },
];

/** Editar datos y rol de un usuario. Solo Administrador. */
export default function EditarUsuario() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { usuario: yo } = useAuth();
  const soyYo = String(yo?.idUsuario) === String(id);

  const [nombre, setNombre] = useState('');
  const [correo, setCorreo] = useState('');
  const [rol, setRol] = useState('Usuario');
  const [cargando, setCargando] = useState(true);
  const [errorCarga, setErrorCarga] = useState('');
  const [error, setError] = useState('');
  const [procesando, setProcesando] = useState('');
  const [prestamos, setPrestamos] = useState([]);

  const cargar = useCallback(() => {
    return Promise.all([usuariosApi.obtener(id), prestamosApi.listar({ idUsuario: id })])
      .then(([u, listaPrestamos]) => {
        setErrorCarga('');
        setPrestamos(listaPrestamos);
        setNombre(u.nombre);
        setCorreo(u.correo);
        setRol(u.rol);
      })
      .catch((e) => setErrorCarga(e.message))
      .finally(() => setCargando(false));
  }, [id]);

  function reintentar() {
    setCargando(true);
    setErrorCarga('');
    cargar();
  }

  useEffect(() => {
    cargar();
  }, [cargar]);

  async function guardar() {
    setError('');
    if (!nombre.trim() || !correo.trim()) {
      setError('Nombre y correo son obligatorios.');
      return;
    }
    setProcesando('guardar');
    try {
      await usuariosApi.actualizar(id, { nombre: nombre.trim(), correo: correo.trim(), rol });
      router.back();
    } catch (e) {
      setError(e.message);
      setProcesando('');
    }
  }

  async function eliminar() {
    if (!(await confirmar('Eliminar usuario', `¿Eliminar a ${nombre}?`, 'Eliminar'))) return;
    setProcesando('eliminar');
    try {
      await usuariosApi.eliminar(id);
      router.back();
    } catch (e) {
      setProcesando('');
      avisar('No se pudo eliminar', e.message);
    }
  }

  if (cargando) return <Cargando />;
  if (errorCarga) return <ErrorCarga mensaje={errorCarga} onReintentar={reintentar} />;

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <Stack.Screen options={{ title: nombre || 'Usuario' }} />
      <ScrollView contentContainerStyle={styles.contenido} keyboardShouldPersistTaps="handled">
        <Campo etiqueta="Nombre" value={nombre} onChangeText={setNombre} />
        <Campo
          etiqueta="Correo"
          value={correo}
          onChangeText={setCorreo}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
        />
        <Text style={styles.etiqueta}>Rol</Text>
        <Selector opciones={ROLES} valor={rol} onCambiar={soyYo ? () => {} : setRol} />
        {soyYo ? <Text style={styles.nota}>No puedes cambiar tu propio rol.</Text> : null}

        {error ? <Text style={styles.error}>{error}</Text> : null}

        <Boton
          titulo="Guardar cambios"
          icono="save-outline"
          onPress={guardar}
          cargando={procesando === 'guardar'}
          estilo={styles.boton}
        />
        <Text style={styles.seccion}>Préstamos de este usuario ({prestamos.length})</Text>
        {prestamos.length === 0 ? (
          <Text style={styles.nota}>Todavía no tiene préstamos.</Text>
        ) : (
          prestamos.map((p) => (
            <Tarjeta key={p.idPrestamo} onPress={() => router.push(`/prestamo/${p.idPrestamo}`)}>
              <View style={styles.filaPrestamo}>
                <Text style={styles.numero}>Préstamo #{p.idPrestamo}</Text>
                <Insignia texto={p.estado} tipo={p.estado === 'Activo' ? 'advertencia' : 'exito'} />
              </View>
              <Text style={styles.libros} numberOfLines={2}>
                {p.detalles
                  .map((d) => (d.cantidad > 1 ? `${d.titulo} (x${d.cantidad})` : d.titulo))
                  .join(' · ')}
              </Text>
              <Text style={styles.meta}>{formatearFecha(p.fechaPrestamo)}</Text>
            </Tarjeta>
          ))
        )}

        {!soyYo ? (
          <Boton
            titulo="Eliminar usuario"
            icono="trash-outline"
            variante="peligro"
            onPress={eliminar}
            cargando={procesando === 'eliminar'}
            estilo={styles.boton}
            deshabilitado={prestamos.length > 0}
          />
        ) : null}
        {!soyYo && prestamos.length > 0 ? (
          <Text style={styles.nota}>
            No se puede eliminar un usuario con historial de préstamos.
          </Text>
        ) : null}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20 },
  etiqueta: { fontSize: 14, fontWeight: '600', color: colores.texto, marginBottom: 6 },
  nota: { color: colores.textoSuave, fontSize: 13, marginTop: 6 },
  error: {
    color: colores.peligro,
    backgroundColor: colores.peligroSuave,
    padding: 10,
    borderRadius: 8,
    marginTop: 14,
  },
  boton: { marginTop: 14 },
  seccion: {
    fontSize: 15,
    fontWeight: '700',
    color: colores.texto,
    marginTop: 24,
    marginBottom: 8,
  },
  filaPrestamo: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  numero: { fontSize: 15, fontWeight: '700', color: colores.texto },
  libros: { fontSize: 14, color: colores.texto, marginTop: 6 },
  meta: { fontSize: 12, color: colores.textoSuave, marginTop: 4 },
});
