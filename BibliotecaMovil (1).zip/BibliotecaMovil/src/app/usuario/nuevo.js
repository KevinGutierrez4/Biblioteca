import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text } from 'react-native';
import { useRouter } from 'expo-router';
import Boton from '../../components/Boton';
import Campo from '../../components/Campo';
import Selector from '../../components/Selector';
import { authApi, usuariosApi } from '../../api/servicios';
import { colores } from '../../theme';

const ROLES = [
  { valor: 'Usuario', texto: 'Usuario' },
  { valor: 'Administrador', texto: 'Administrador' },
];

const CORREO_VALIDO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * Crear usuario (solo Administrador).
 * 1) POST /api/auth/register crea la cuenta (siempre con rol "Usuario").
 * 2) Si se eligió "Administrador", PUT /api/usuarios/{id} le asigna ese rol.
 */
export default function NuevoUsuario() {
  const router = useRouter();

  const [nombre, setNombre] = useState('');
  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [rol, setRol] = useState('Usuario');
  const [errores, setErrores] = useState({});
  const [errorGeneral, setErrorGeneral] = useState('');
  const [guardando, setGuardando] = useState(false);

  function validar() {
    const e = {};
    if (!nombre.trim()) e.nombre = 'El nombre es obligatorio.';
    else if (nombre.trim().length > 100) e.nombre = 'Máximo 100 caracteres.';
    if (!CORREO_VALIDO.test(correo.trim())) e.correo = 'Escribe un correo válido.';
    if (password.length < 8) e.password = 'Mínimo 8 caracteres.';
    setErrores(e);
    return Object.keys(e).length === 0;
  }

  async function guardar() {
    setErrorGeneral('');
    if (!validar()) return;
    setGuardando(true);
    try {
      const creado = await authApi.registro(nombre.trim(), correo.trim(), password);
      if (rol === 'Administrador') {
        await usuariosApi.actualizar(creado.idUsuario, {
          nombre: creado.nombre,
          correo: creado.correo,
          rol,
        });
      }
      router.back();
    } catch (e) {
      setErrorGeneral(e.message);
      setGuardando(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.contenido} keyboardShouldPersistTaps="handled">
        <Campo etiqueta="Nombre" value={nombre} onChangeText={setNombre} error={errores.nombre} />
        <Campo
          etiqueta="Correo"
          value={correo}
          onChangeText={setCorreo}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
          error={errores.correo}
        />
        <Campo
          etiqueta="Contraseña inicial"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          autoCapitalize="none"
          placeholder="Mínimo 8 caracteres"
          error={errores.password}
        />
        <Text style={styles.etiqueta}>Rol</Text>
        <Selector opciones={ROLES} valor={rol} onCambiar={setRol} />

        {errorGeneral ? <Text style={styles.error}>{errorGeneral}</Text> : null}

        <Boton
          titulo="Crear usuario"
          icono="person-add-outline"
          onPress={guardar}
          cargando={guardando}
          estilo={styles.boton}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20 },
  etiqueta: { fontSize: 14, fontWeight: '600', color: colores.texto, marginBottom: 6 },
  error: {
    color: colores.peligro,
    backgroundColor: colores.peligroSuave,
    padding: 10,
    borderRadius: 8,
    marginTop: 14,
  },
  boton: { marginTop: 18 },
});
