import { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import Boton from '../components/Boton';
import Campo from '../components/Campo';
import { Cargando } from '../components/Estados';
import { librosApi } from '../api/servicios';
import { colores } from '../theme';

/** Crea un libro (sin parámetro) o edita uno existente (?id=5). Solo Administrador. */
export default function FormularioLibro() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const editando = !!id;

  const [titulo, setTitulo] = useState('');
  const [autor, setAutor] = useState('');
  const [isbn, setIsbn] = useState('');
  const [cantidad, setCantidad] = useState('1');
  const [errores, setErrores] = useState({});
  const [errorGeneral, setErrorGeneral] = useState('');
  const [cargando, setCargando] = useState(editando);
  const [guardando, setGuardando] = useState(false);

  useEffect(() => {
    if (!editando) return;
    librosApi
      .obtener(id)
      .then((l) => {
        setTitulo(l.titulo);
        setAutor(l.autor);
        setIsbn(l.isbn);
        setCantidad(String(l.cantidadDisponible));
      })
      .catch((e) => setErrorGeneral(e.message))
      .finally(() => setCargando(false));
  }, [editando, id]);

  function validar() {
    const e = {};
    if (!titulo.trim()) e.titulo = 'El título es obligatorio.';
    else if (titulo.trim().length > 150) e.titulo = 'Máximo 150 caracteres.';
    if (!autor.trim()) e.autor = 'El autor es obligatorio.';
    else if (autor.trim().length > 100) e.autor = 'Máximo 100 caracteres.';
    if (!isbn.trim()) e.isbn = 'El ISBN es obligatorio.';
    else if (isbn.trim().length > 20) e.isbn = 'Máximo 20 caracteres.';
    const n = Number(cantidad);
    if (!/^\d+$/.test(cantidad) || n < 0 || n > 10000) e.cantidad = 'Número entre 0 y 10000.';
    setErrores(e);
    return Object.keys(e).length === 0;
  }

  async function guardar() {
    setErrorGeneral('');
    if (!validar()) return;
    setGuardando(true);
    const datos = {
      titulo: titulo.trim(),
      autor: autor.trim(),
      isbn: isbn.trim(),
      cantidadDisponible: Number(cantidad),
    };
    try {
      if (editando) await librosApi.actualizar(id, datos);
      else await librosApi.crear(datos);
      router.back();
    } catch (e) {
      setErrorGeneral(e.message);
      setGuardando(false);
    }
  }

  if (cargando) return <Cargando />;

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <Stack.Screen options={{ title: editando ? 'Editar libro' : 'Nuevo libro' }} />
      <ScrollView contentContainerStyle={styles.contenido} keyboardShouldPersistTaps="handled">
        <Campo etiqueta="Título" value={titulo} onChangeText={setTitulo} error={errores.titulo} />
        <Campo etiqueta="Autor" value={autor} onChangeText={setAutor} error={errores.autor} />
        <Campo
          etiqueta="ISBN"
          value={isbn}
          onChangeText={setIsbn}
          autoCapitalize="characters"
          error={errores.isbn}
        />
        <Campo
          etiqueta="Ejemplares disponibles"
          value={cantidad}
          onChangeText={(t) => setCantidad(t.replace(/[^0-9]/g, ''))}
          keyboardType="number-pad"
          error={errores.cantidad}
        />
        {errorGeneral ? <Text style={styles.error}>{errorGeneral}</Text> : null}
        <Boton
          titulo={editando ? 'Guardar cambios' : 'Crear libro'}
          icono="save-outline"
          onPress={guardar}
          cargando={guardando}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20 },
  error: {
    color: colores.peligro,
    backgroundColor: colores.peligroSuave,
    padding: 10,
    borderRadius: 8,
    marginBottom: 14,
  },
});
