import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { colores } from '../../theme';

const icono = (nombre) =>
  function IconoTab({ color, size }) {
    return <Ionicons name={nombre} size={size} color={color} />;
  };

export default function TabsLayout() {
  const { esAdmin } = useAuth();

  return (
    <Tabs
      screenOptions={{
        headerStyle: { backgroundColor: colores.primario },
        headerTintColor: colores.blanco,
        headerTitleStyle: { fontWeight: '700' },
        tabBarActiveTintColor: colores.primario,
        tabBarInactiveTintColor: colores.textoSuave,
        sceneStyle: { backgroundColor: colores.fondo },
      }}
    >
      <Tabs.Screen name="libros" options={{ title: 'Libros', tabBarIcon: icono('book-outline') }} />
      <Tabs.Screen
        name="prestamos"
        options={{ title: 'Préstamos', tabBarIcon: icono('swap-horizontal-outline') }}
      />
      <Tabs.Screen
        name="usuarios"
        options={{
          title: 'Usuarios',
          tabBarIcon: icono('people-outline'),
          // Solo el Administrador ve esta pestaña.
          ...(esAdmin ? {} : { href: null }),
        }}
      />
      <Tabs.Screen
        name="perfil"
        options={{ title: 'Perfil', tabBarIcon: icono('person-circle-outline') }}
      />
    </Tabs>
  );
}
