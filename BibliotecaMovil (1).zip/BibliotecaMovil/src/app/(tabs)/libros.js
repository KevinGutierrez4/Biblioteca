import { useCallback, useEffect, useState } from 'react';
import { FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Campo from '../../components/Campo';
import Tarjeta from '../../components/Tarjeta';
import Insignia from '../../components/Insignia';
import BotonFlotante from '../../components/BotonFlotante';
import { Cargando, ErrorCarga, Vacio } from '../../components/Estados';
import { librosApi } from '../../api/servicios';
import { useAuth } from '../../context/AuthContext';
import { colores } from '../../theme';

export default function Libros() {
  const router = useRouter();
  const { esAdmin } = useAuth();

  const [libros, setLibros] = useState([]);
  const [buscar, setBuscar] = useState('');
  const [busquedaAplicada, setBusquedaAplicada] = useState('');
  const [cargando, setCargando] = useState(true);
  const [refrescando, setRefrescando] = useState(false);
  const [error, setError] = useState('');

  const cargar = useCallback(async (texto) => {
    try {
      setError('');
      setLibros(await librosApi.listar(texto));
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
      setRefrescando(false);
    }
  }, []);

  // Espera 400 ms después de escribir antes de buscar en el backend.
  useEffect(() => {
    const t = setTimeout(() => setBusquedaAplicada(buscar.trim()), 400);
    return () => clearTimeout(t);
  }, [buscar]);

  // Recarga al entrar a la pestaña o al cambiar la búsqueda (ej. al volver de editar).
  useFocusEffect(
    useCallback(() => {
      cargar(busquedaAplicada);
    }, [cargar, busquedaAplicada]),
  );

  if (cargando) return <Cargando />;
  if (error && libros.length === 0) {
    return (
      <ErrorCarga
        mensaje={error}
        onReintentar={() => {
          setCargando(true);
          cargar(busquedaAplicada);
        }}
      />
    );
  }

  return (
    <View style={styles.pantalla}>
      <FlatList
        data={libros}
        keyExtractor={(l) => String(l.idLibro)}
        contentContainerStyle={styles.lista}
        keyboardShouldPersistTaps="handled"
        refreshControl={
          <RefreshControl
            refreshing={refrescando}
            onRefresh={() => {
              setRefrescando(true);
              cargar(busquedaAplicada);
            }}
            colors={[colores.primario]}
          />
        }
        ListHeaderComponent={
          <Campo
            value={buscar}
            onChangeText={setBuscar}
            placeholder="Buscar por título, autor o ISBN"
            autoCorrect={false}
            estilo={styles.buscador}
          />
        }
        ListEmptyComponent={
          <Vacio
            icono="book-outline"
            texto={
              busquedaAplicada ? 'No hay libros que coincidan.' : 'Aún no hay libros registrados.'
            }
          />
        }
        renderItem={({ item }) => (
          <Tarjeta onPress={() => router.push(`/libro/${item.idLibro}`)}>
            <View style={styles.fila}>
              <View style={styles.icono}>
                <Ionicons name="book" size={22} color={colores.primario} />
              </View>
              <View style={styles.info}>
                <Text style={styles.titulo} numberOfLines={2}>
                  {item.titulo}
                </Text>
                <Text style={styles.autor} numberOfLines={1}>
                  {item.autor}
                </Text>
                <Text style={styles.isbn}>ISBN {item.isbn}</Text>
              </View>
              <Insignia
                texto={item.cantidadDisponible > 0 ? `${item.cantidadDisponible} disp.` : 'Agotado'}
                tipo={item.cantidadDisponible > 0 ? 'exito' : 'peligro'}
              />
            </View>
          </Tarjeta>
        )}
      />
      {esAdmin ? (
        <BotonFlotante texto="Nuevo libro" onPress={() => router.push('/libro-form')} />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  pantalla: { flex: 1, backgroundColor: colores.fondo },
  lista: { padding: 16, paddingBottom: 96 },
  buscador: { marginBottom: 12 },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  icono: {
    width: 44,
    height: 44,
    borderRadius: 10,
    backgroundColor: colores.primarioSuave,
    alignItems: 'center',
    justifyContent: 'center',
  },
  info: { flex: 1 },
  titulo: { fontSize: 16, fontWeight: '700', color: colores.texto },
  autor: { fontSize: 14, color: colores.textoSuave, marginTop: 2 },
  isbn: { fontSize: 12, color: colores.textoSuave, marginTop: 2 },
});
