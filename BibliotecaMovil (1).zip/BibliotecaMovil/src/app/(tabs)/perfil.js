import { useCallback, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Boton from '../../components/Boton';
import Insignia from '../../components/Insignia';
import { usuariosApi } from '../../api/servicios';
import { obtenerServidor } from '../../api/config';
import { useAuth } from '../../context/AuthContext';
import { formatearFecha } from '../../utils/fechas';
import { confirmar } from '../../utils/confirmar';
import { colores } from '../../theme';

export default function Perfil() {
  const router = useRouter();
  const { usuario, sesion, cerrarSesion } = useAuth();
  const [datos, setDatos] = useState(usuario);
  const [servidor, setServidor] = useState(obtenerServidor());

  // Consulta /api/usuarios/me para mostrar los datos actuales del backend.
  useFocusEffect(
    useCallback(() => {
      setServidor(obtenerServidor());
      usuariosApi
        .yo()
        .then(setDatos)
        .catch(() => {});
    }, []),
  );

  async function salir() {
    if (await confirmar('Cerrar sesión', '¿Seguro que quieres salir?', 'Salir')) {
      await cerrarSesion();
    }
  }

  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      <View style={styles.tarjeta}>
        <View style={styles.avatar}>
          <Text style={styles.inicial}>{(datos?.nombre || '?').charAt(0).toUpperCase()}</Text>
        </View>
        <Text style={styles.nombre}>{datos?.nombre}</Text>
        <Text style={styles.correo}>{datos?.correo}</Text>
        <Insignia
          texto={datos?.rol ?? ''}
          tipo={datos?.rol === 'Administrador' ? 'info' : 'exito'}
        />
      </View>

      <View style={styles.seccion}>
        <Fila icono="server-outline" etiqueta="Servidor" valor={servidor} />
        <Fila
          icono="time-outline"
          etiqueta="La sesión vence"
          valor={formatearFecha(sesion?.expiracion)}
        />
      </View>

      <View style={styles.botones}>
        <Boton
          titulo="Cambiar servidor"
          icono="settings-outline"
          variante="secundario"
          onPress={() => router.push('/servidor')}
        />
        <Boton titulo="Cerrar sesión" icono="log-out-outline" variante="peligro" onPress={salir} />
      </View>
    </ScrollView>
  );
}

function Fila({ icono, etiqueta, valor }) {
  return (
    <View style={styles.fila}>
      <Ionicons name={icono} size={20} color={colores.textoSuave} />
      <Text style={styles.filaEtiqueta}>{etiqueta}</Text>
      <Text style={styles.filaValor} numberOfLines={1}>
        {valor}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 16, gap: 16 },
  tarjeta: {
    backgroundColor: colores.tarjeta,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colores.borde,
    padding: 24,
    alignItems: 'center',
    gap: 6,
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colores.primario,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  inicial: { color: colores.blanco, fontSize: 30, fontWeight: '800' },
  nombre: { fontSize: 20, fontWeight: '800', color: colores.texto },
  correo: { fontSize: 15, color: colores.textoSuave, marginBottom: 4 },
  seccion: {
    backgroundColor: colores.tarjeta,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colores.borde,
    paddingHorizontal: 16,
  },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 14 },
  filaEtiqueta: { color: colores.texto, fontSize: 15 },
  filaValor: { flex: 1, textAlign: 'right', color: colores.textoSuave, fontSize: 14 },
  botones: { gap: 10 },
});
