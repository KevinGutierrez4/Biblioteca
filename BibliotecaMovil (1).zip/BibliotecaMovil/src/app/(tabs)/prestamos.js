import { useCallback, useState } from 'react';
import { FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import Tarjeta from '../../components/Tarjeta';
import Insignia from '../../components/Insignia';
import Selector from '../../components/Selector';
import BotonFlotante from '../../components/BotonFlotante';
import { Cargando, ErrorCarga, Vacio } from '../../components/Estados';
import { prestamosApi, usuariosApi } from '../../api/servicios';
import { useAuth } from '../../context/AuthContext';
import { formatearFecha } from '../../utils/fechas';
import { colores } from '../../theme';

const FILTROS = [
  { valor: '', texto: 'Todos' },
  { valor: 'Activo', texto: 'Activos' },
  { valor: 'Devuelto', texto: 'Devueltos' },
];

export default function Prestamos() {
  const router = useRouter();
  const { esAdmin } = useAuth();

  const [prestamos, setPrestamos] = useState([]);
  const [estado, setEstado] = useState('');
  const [cargando, setCargando] = useState(true);
  const [refrescando, setRefrescando] = useState(false);
  const [error, setError] = useState('');
  const [usuarios, setUsuarios] = useState([]);
  const [idUsuario, setIdUsuario] = useState(0); // 0 = todos (solo Administrador)

  const cargar = useCallback(async (filtro, usuarioFiltro) => {
    try {
      setError('');
      setPrestamos(
        await prestamosApi.listar({
          estado: filtro,
          idUsuario: usuarioFiltro > 0 ? usuarioFiltro : undefined,
        }),
      );
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
      setRefrescando(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      cargar(estado, idUsuario);
    }, [cargar, estado, idUsuario]),
  );

  // El Administrador puede filtrar por usuario.
  useFocusEffect(
    useCallback(() => {
      if (esAdmin)
        usuariosApi
          .listar()
          .then(setUsuarios)
          .catch(() => {});
    }, [esAdmin]),
  );

  if (cargando) return <Cargando />;
  if (error && prestamos.length === 0) {
    return (
      <ErrorCarga
        mensaje={error}
        onReintentar={() => {
          setCargando(true);
          cargar(estado, idUsuario);
        }}
      />
    );
  }

  return (
    <View style={styles.pantalla}>
      <FlatList
        data={prestamos}
        keyExtractor={(p) => String(p.idPrestamo)}
        contentContainerStyle={styles.lista}
        refreshControl={
          <RefreshControl
            refreshing={refrescando}
            onRefresh={() => {
              setRefrescando(true);
              cargar(estado, idUsuario);
            }}
            colors={[colores.primario]}
          />
        }
        ListHeaderComponent={
          <View style={styles.cabecera}>
            <Text style={styles.subtitulo}>
              {esAdmin ? 'Préstamos de todos los usuarios' : 'Mis préstamos'}
            </Text>
            <Selector opciones={FILTROS} valor={estado} onCambiar={setEstado} />
            {esAdmin && usuarios.length > 0 ? (
              <Selector
                opciones={[
                  { valor: 0, texto: 'Todos los usuarios' },
                  ...usuarios.map((u) => ({ valor: u.idUsuario, texto: u.nombre })),
                ]}
                valor={idUsuario}
                onCambiar={setIdUsuario}
              />
            ) : null}
          </View>
        }
        ListEmptyComponent={
          <Vacio icono="swap-horizontal-outline" texto="No hay préstamos para mostrar." />
        }
        renderItem={({ item }) => {
          const totalLibros = item.detalles.reduce((s, d) => s + d.cantidad, 0);
          return (
            <Tarjeta onPress={() => router.push(`/prestamo/${item.idPrestamo}`)}>
              <View style={styles.filaSuperior}>
                <Text style={styles.numero}>Préstamo #{item.idPrestamo}</Text>
                <Insignia
                  texto={item.estado}
                  tipo={item.estado === 'Activo' ? 'advertencia' : 'exito'}
                />
              </View>
              {esAdmin ? <Text style={styles.usuario}>{item.usuario.nombre}</Text> : null}
              <Text style={styles.libros} numberOfLines={2}>
                {item.detalles
                  .map((d) => (d.cantidad > 1 ? `${d.titulo} (x${d.cantidad})` : d.titulo))
                  .join(' · ')}
              </Text>
              <Text style={styles.meta}>
                {formatearFecha(item.fechaPrestamo)} · {totalLibros}{' '}
                {totalLibros === 1 ? 'libro' : 'libros'}
              </Text>
            </Tarjeta>
          );
        }}
      />
      <BotonFlotante texto="Nuevo préstamo" onPress={() => router.push('/nuevo-prestamo')} />
    </View>
  );
}

const styles = StyleSheet.create({
  pantalla: { flex: 1, backgroundColor: colores.fondo },
  lista: { padding: 16, paddingBottom: 96 },
  cabecera: { marginBottom: 12, gap: 8 },
  subtitulo: { color: colores.textoSuave, fontSize: 14 },
  filaSuperior: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  numero: { fontSize: 16, fontWeight: '700', color: colores.texto },
  usuario: { fontSize: 14, color: colores.primario, fontWeight: '600', marginTop: 4 },
  libros: { fontSize: 14, color: colores.texto, marginTop: 6 },
  meta: { fontSize: 12, color: colores.textoSuave, marginTop: 6 },
});
