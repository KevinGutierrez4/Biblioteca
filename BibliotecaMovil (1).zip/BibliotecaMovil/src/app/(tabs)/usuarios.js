import { useCallback, useMemo, useState } from 'react';
import { FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Redirect, useFocusEffect, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Tarjeta from '../../components/Tarjeta';
import Insignia from '../../components/Insignia';
import Campo from '../../components/Campo';
import BotonFlotante from '../../components/BotonFlotante';
import { Cargando, ErrorCarga, Vacio } from '../../components/Estados';
import { usuariosApi } from '../../api/servicios';
import { useAuth } from '../../context/AuthContext';
import { colores } from '../../theme';

export default function Usuarios() {
  const router = useRouter();
  const { esAdmin, usuario: yo } = useAuth();

  const [usuarios, setUsuarios] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [refrescando, setRefrescando] = useState(false);
  const [error, setError] = useState('');
  const [buscar, setBuscar] = useState('');

  const filtrados = useMemo(() => {
    const t = buscar.trim().toLowerCase();
    if (!t) return usuarios;
    return usuarios.filter(
      (u) => u.nombre.toLowerCase().includes(t) || u.correo.toLowerCase().includes(t),
    );
  }, [usuarios, buscar]);

  const cargar = useCallback(async () => {
    try {
      setError('');
      setUsuarios(await usuariosApi.listar());
    } catch (e) {
      setError(e.message);
    } finally {
      setCargando(false);
      setRefrescando(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (esAdmin) cargar();
    }, [cargar, esAdmin]),
  );

  if (!esAdmin) return <Redirect href="/libros" />;
  if (cargando) return <Cargando />;
  if (error && usuarios.length === 0) {
    return (
      <ErrorCarga
        mensaje={error}
        onReintentar={() => {
          setCargando(true);
          cargar();
        }}
      />
    );
  }

  return (
    <View style={styles.pantalla}>
      <FlatList
        data={filtrados}
        keyExtractor={(u) => String(u.idUsuario)}
        contentContainerStyle={styles.lista}
        refreshControl={
          <RefreshControl
            refreshing={refrescando}
            onRefresh={() => {
              setRefrescando(true);
              cargar();
            }}
            colors={[colores.primario]}
          />
        }
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <Campo
            value={buscar}
            onChangeText={setBuscar}
            placeholder="Buscar por nombre o correo"
            autoCapitalize="none"
            autoCorrect={false}
            estilo={styles.buscador}
          />
        }
        ListEmptyComponent={<Vacio icono="people-outline" texto="No hay usuarios que coincidan." />}
        renderItem={({ item }) => (
          <Tarjeta onPress={() => router.push(`/usuario/${item.idUsuario}`)}>
            <View style={styles.fila}>
              <Ionicons
                name={item.rol === 'Administrador' ? 'shield-checkmark' : 'person'}
                size={26}
                color={colores.primario}
              />
              <View style={styles.info}>
                <Text style={styles.nombre}>
                  {item.nombre}
                  {item.idUsuario === yo?.idUsuario ? ' (tú)' : ''}
                </Text>
                <Text style={styles.correo}>{item.correo}</Text>
              </View>
              <Insignia texto={item.rol} tipo={item.rol === 'Administrador' ? 'info' : 'exito'} />
            </View>
          </Tarjeta>
        )}
      />
      <BotonFlotante
        texto="Nuevo usuario"
        icono="person-add"
        onPress={() => router.push('/usuario/nuevo')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  pantalla: { flex: 1, backgroundColor: colores.fondo },
  lista: { padding: 16, paddingBottom: 96 },
  buscador: { marginBottom: 12 },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  info: { flex: 1 },
  nombre: { fontSize: 16, fontWeight: '700', color: colores.texto },
  correo: { fontSize: 14, color: colores.textoSuave, marginTop: 2 },
});
