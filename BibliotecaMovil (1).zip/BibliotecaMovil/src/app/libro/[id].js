import { useCallback, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Stack, useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Boton from '../../components/Boton';
import Insignia from '../../components/Insignia';
import { Cargando, ErrorCarga } from '../../components/Estados';
import { librosApi } from '../../api/servicios';
import { useAuth } from '../../context/AuthContext';
import { avisar, confirmar } from '../../utils/confirmar';
import { colores } from '../../theme';

export default function DetalleLibro() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { esAdmin } = useAuth();

  const [libro, setLibro] = useState(null);
  const [error, setError] = useState('');
  const [eliminando, setEliminando] = useState(false);

  const cargar = useCallback(async () => {
    try {
      setError('');
      setLibro(await librosApi.obtener(id));
    } catch (e) {
      setError(e.message);
    }
  }, [id]);

  useFocusEffect(
    useCallback(() => {
      cargar();
    }, [cargar]),
  );

  async function eliminar() {
    const ok = await confirmar('Eliminar libro', `¿Eliminar "${libro.titulo}"?`, 'Eliminar');
    if (!ok) return;
    setEliminando(true);
    try {
      await librosApi.eliminar(id);
      router.back();
    } catch (e) {
      setEliminando(false);
      avisar('No se pudo eliminar', e.message);
    }
  }

  if (error && !libro) return <ErrorCarga mensaje={error} onReintentar={cargar} />;
  if (!libro) return <Cargando />;

  const disponible = libro.cantidadDisponible > 0;

  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      <Stack.Screen options={{ title: libro.titulo }} />

      <View style={styles.portada}>
        <Ionicons name="book" size={56} color={colores.primario} />
      </View>

      <Text style={styles.titulo}>{libro.titulo}</Text>
      <Text style={styles.autor}>{libro.autor}</Text>

      <View style={styles.datos}>
        <Dato etiqueta="ISBN" valor={libro.isbn} />
        <Dato etiqueta="Ejemplares disponibles" valor={String(libro.cantidadDisponible)} />
        <View style={styles.estado}>
          <Insignia
            texto={disponible ? 'Disponible' : 'Agotado'}
            tipo={disponible ? 'exito' : 'peligro'}
          />
        </View>
      </View>

      <View style={styles.botones}>
        <Boton
          titulo="Pedir prestado"
          icono="bookmark-outline"
          deshabilitado={!disponible}
          onPress={() =>
            router.push({ pathname: '/nuevo-prestamo', params: { idLibro: libro.idLibro } })
          }
        />
        {esAdmin ? (
          <>
            <Boton
              titulo="Editar"
              icono="create-outline"
              variante="secundario"
              onPress={() =>
                router.push({ pathname: '/libro-form', params: { id: libro.idLibro } })
              }
            />
            <Boton
              titulo="Eliminar"
              icono="trash-outline"
              variante="peligro"
              onPress={eliminar}
              cargando={eliminando}
            />
          </>
        ) : null}
      </View>
    </ScrollView>
  );
}

function Dato({ etiqueta, valor }) {
  return (
    <View style={styles.dato}>
      <Text style={styles.datoEtiqueta}>{etiqueta}</Text>
      <Text style={styles.datoValor}>{valor}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20 },
  portada: {
    alignSelf: 'center',
    width: 110,
    height: 140,
    borderRadius: 12,
    backgroundColor: colores.primarioSuave,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  titulo: { fontSize: 22, fontWeight: '800', color: colores.texto, textAlign: 'center' },
  autor: { fontSize: 16, color: colores.textoSuave, textAlign: 'center', marginTop: 4 },
  datos: {
    marginTop: 20,
    backgroundColor: colores.tarjeta,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colores.borde,
    paddingHorizontal: 16,
  },
  dato: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colores.borde,
  },
  datoEtiqueta: { color: colores.textoSuave, fontSize: 15 },
  datoValor: { color: colores.texto, fontSize: 15, fontWeight: '600' },
  estado: { paddingVertical: 14 },
  botones: { marginTop: 24, gap: 10 },
});
