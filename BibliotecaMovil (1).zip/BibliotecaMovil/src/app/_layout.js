import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider, useAuth } from '../context/AuthContext';
import { Cargando } from '../components/Estados';
import { colores } from '../theme';

export default function RootLayout() {
  return (
    <AuthProvider>
      <StatusBar style="light" />
      <Navegacion />
    </AuthProvider>
  );
}

function Navegacion() {
  const { sesion, cargando } = useAuth();

  if (cargando) return <Cargando texto="Iniciando…" />;

  const conSesion = !!sesion;

  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colores.primario },
        headerTintColor: colores.blanco,
        headerTitleStyle: { fontWeight: '700' },
        contentStyle: { backgroundColor: colores.fondo },
      }}
    >
      {/* Redirige a /login o /libros según haya sesión */}
      <Stack.Screen name="index" options={{ headerShown: false }} />

      {/* Pantallas que requieren iniciar sesión */}
      <Stack.Protected guard={conSesion}>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="libro/[id]" options={{ title: 'Libro' }} />
        <Stack.Screen name="libro-form" options={{ title: 'Libro' }} />
        <Stack.Screen name="nuevo-prestamo" options={{ title: 'Nuevo préstamo' }} />
        <Stack.Screen name="prestamo/[id]" options={{ title: 'Préstamo' }} />
        <Stack.Screen name="usuario/nuevo" options={{ title: 'Nuevo usuario' }} />
        <Stack.Screen name="usuario/[id]" options={{ title: 'Usuario' }} />
      </Stack.Protected>

      {/* Pantallas solo para quien no ha iniciado sesión */}
      <Stack.Protected guard={!conSesion}>
        <Stack.Screen name="login" options={{ headerShown: false }} />
        <Stack.Screen name="registro" options={{ title: 'Crear cuenta' }} />
      </Stack.Protected>

      {/* Disponible siempre: configurar la IP del backend */}
      <Stack.Screen name="servidor" options={{ title: 'Servidor' }} />
    </Stack>
  );
}
