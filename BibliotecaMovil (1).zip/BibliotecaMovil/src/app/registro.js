import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text } from 'react-native';
import Boton from '../components/Boton';
import Campo from '../components/Campo';
import { authApi } from '../api/servicios';
import { useAuth } from '../context/AuthContext';
import { colores } from '../theme';

const CORREO_VALIDO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Registro() {
  const { iniciarSesion } = useAuth();

  const [nombre, setNombre] = useState('');
  const [correo, setCorreo] = useState('');
  const [password, setPassword] = useState('');
  const [confirmacion, setConfirmacion] = useState('');
  const [errores, setErrores] = useState({});
  const [errorGeneral, setErrorGeneral] = useState('');
  const [enviando, setEnviando] = useState(false);

  function validar() {
    const e = {};
    if (!nombre.trim()) e.nombre = 'El nombre es obligatorio.';
    if (!CORREO_VALIDO.test(correo.trim())) e.correo = 'Escribe un correo válido.';
    if (password.length < 8) e.password = 'Mínimo 8 caracteres.';
    if (confirmacion !== password) e.confirmacion = 'Las contraseñas no coinciden.';
    setErrores(e);
    return Object.keys(e).length === 0;
  }

  async function registrar() {
    setErrorGeneral('');
    if (!validar()) return;
    setEnviando(true);
    try {
      await authApi.registro(nombre.trim(), correo.trim(), password);
      // Inicia sesión automáticamente con la cuenta nueva.
      await iniciarSesion(correo, password);
    } catch (e) {
      setErrorGeneral(e.message);
      setEnviando(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.contenido} keyboardShouldPersistTaps="handled">
        <Text style={styles.intro}>Crea tu cuenta para solicitar préstamos de libros.</Text>
        <Campo etiqueta="Nombre" value={nombre} onChangeText={setNombre} error={errores.nombre} />
        <Campo
          etiqueta="Correo"
          value={correo}
          onChangeText={setCorreo}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
          error={errores.correo}
        />
        <Campo
          etiqueta="Contraseña"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          autoCapitalize="none"
          error={errores.password}
        />
        <Campo
          etiqueta="Repite la contraseña"
          value={confirmacion}
          onChangeText={setConfirmacion}
          secureTextEntry
          autoCapitalize="none"
          error={errores.confirmacion}
        />
        {errorGeneral ? <Text style={styles.error}>{errorGeneral}</Text> : null}
        <Boton
          titulo="Crear cuenta"
          icono="person-add-outline"
          onPress={registrar}
          cargando={enviando}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 20 },
  intro: { color: colores.textoSuave, fontSize: 15, marginBottom: 18 },
  error: {
    color: colores.peligro,
    backgroundColor: colores.peligroSuave,
    padding: 10,
    borderRadius: 8,
    marginBottom: 14,
  },
});
