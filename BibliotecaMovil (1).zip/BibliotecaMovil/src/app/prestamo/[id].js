import { useCallback, useState } from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Stack, useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Boton from '../../components/Boton';
import Insignia from '../../components/Insignia';
import { Cargando, ErrorCarga } from '../../components/Estados';
import { prestamosApi } from '../../api/servicios';
import { useAuth } from '../../context/AuthContext';
import { formatearFecha } from '../../utils/fechas';
import { avisar, confirmar } from '../../utils/confirmar';
import { colores } from '../../theme';

export default function DetallePrestamo() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { esAdmin } = useAuth();

  const [prestamo, setPrestamo] = useState(null);
  const [error, setError] = useState('');
  const [procesando, setProcesando] = useState('');

  const cargar = useCallback(async () => {
    try {
      setError('');
      setPrestamo(await prestamosApi.obtener(id));
    } catch (e) {
      setError(e.message);
    }
  }, [id]);

  useFocusEffect(
    useCallback(() => {
      cargar();
    }, [cargar]),
  );

  async function cambiarEstado(nuevo) {
    const texto =
      nuevo === 'Devuelto'
        ? 'Se registrará la devolución y los libros volverán al stock.'
        : 'El préstamo volverá a estar activo y se descontará el stock.';
    if (
      !(await confirmar(
        nuevo === 'Devuelto' ? 'Registrar devolución' : 'Reactivar préstamo',
        texto,
      ))
    )
      return;

    setProcesando('estado');
    try {
      setPrestamo(await prestamosApi.cambiarEstado(id, nuevo));
    } catch (e) {
      avisar('No se pudo actualizar', e.message);
    } finally {
      setProcesando('');
    }
  }

  async function eliminar() {
    const extra = prestamo.estado === 'Activo' ? ' Los libros volverán al stock.' : '';
    if (
      !(await confirmar('Eliminar préstamo', `¿Eliminar el préstamo #${id}?${extra}`, 'Eliminar'))
    )
      return;

    setProcesando('eliminar');
    try {
      await prestamosApi.eliminar(id);
      router.back();
    } catch (e) {
      setProcesando('');
      avisar('No se pudo eliminar', e.message);
    }
  }

  if (error && !prestamo) return <ErrorCarga mensaje={error} onReintentar={cargar} />;
  if (!prestamo) return <Cargando />;

  const activo = prestamo.estado === 'Activo';
  const total = prestamo.detalles.reduce((s, d) => s + d.cantidad, 0);

  return (
    <ScrollView contentContainerStyle={styles.contenido}>
      <Stack.Screen options={{ title: `Préstamo #${prestamo.idPrestamo}` }} />

      <View style={styles.tarjeta}>
        <View style={styles.filaTitulo}>
          <Text style={styles.titulo}>Préstamo #{prestamo.idPrestamo}</Text>
          <Insignia texto={prestamo.estado} tipo={activo ? 'advertencia' : 'exito'} />
        </View>
        <Fila icono="person-outline" etiqueta="Usuario" valor={prestamo.usuario.nombre} />
        <Fila icono="mail-outline" etiqueta="Correo" valor={prestamo.usuario.correo} />
        <Fila
          icono="calendar-outline"
          etiqueta="Fecha de préstamo"
          valor={formatearFecha(prestamo.fechaPrestamo)}
        />
        <Fila
          icono="return-down-back-outline"
          etiqueta="Devolución"
          valor={prestamo.fechaDevolucion ? formatearFecha(prestamo.fechaDevolucion) : 'Pendiente'}
        />
      </View>

      <Text style={styles.seccion}>Libros ({total})</Text>
      <View style={styles.tarjeta}>
        {prestamo.detalles.map((d, i) => (
          <View
            key={d.idDetalle}
            style={[styles.libro, i < prestamo.detalles.length - 1 && styles.separador]}
          >
            <Ionicons name="book-outline" size={22} color={colores.primario} />
            <View style={{ flex: 1 }}>
              <Text style={styles.libroTitulo}>{d.titulo}</Text>
              <Text style={styles.libroAutor}>{d.autor}</Text>
            </View>
            <Text style={styles.libroCantidad}>x{d.cantidad}</Text>
          </View>
        ))}
      </View>

      {esAdmin ? (
        <View style={styles.botones}>
          {activo ? (
            <Boton
              titulo="Registrar devolución"
              icono="checkmark-done-outline"
              variante="exito"
              onPress={() => cambiarEstado('Devuelto')}
              cargando={procesando === 'estado'}
            />
          ) : (
            <Boton
              titulo="Reactivar préstamo"
              icono="refresh-outline"
              variante="secundario"
              onPress={() => cambiarEstado('Activo')}
              cargando={procesando === 'estado'}
            />
          )}
          <Boton
            titulo="Eliminar préstamo"
            icono="trash-outline"
            variante="peligro"
            onPress={eliminar}
            cargando={procesando === 'eliminar'}
          />
        </View>
      ) : activo ? (
        <Text style={styles.nota}>
          Para devolver los libros, acércate a la biblioteca: el administrador registrará la
          devolución.
        </Text>
      ) : null}
    </ScrollView>
  );
}

function Fila({ icono, etiqueta, valor }) {
  return (
    <View style={styles.fila}>
      <Ionicons name={icono} size={18} color={colores.textoSuave} />
      <Text style={styles.filaEtiqueta}>{etiqueta}</Text>
      <Text style={styles.filaValor} numberOfLines={1}>
        {valor}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  contenido: { padding: 16 },
  tarjeta: {
    backgroundColor: colores.tarjeta,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colores.borde,
    padding: 16,
  },
  filaTitulo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  titulo: { fontSize: 18, fontWeight: '800', color: colores.texto },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8 },
  filaEtiqueta: { color: colores.textoSuave, fontSize: 14 },
  filaValor: { flex: 1, textAlign: 'right', color: colores.texto, fontSize: 14, fontWeight: '600' },
  seccion: {
    fontSize: 15,
    fontWeight: '700',
    color: colores.texto,
    marginTop: 20,
    marginBottom: 8,
  },
  libro: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10 },
  separador: { borderBottomWidth: 1, borderBottomColor: colores.borde },
  libroTitulo: { fontSize: 15, fontWeight: '600', color: colores.texto },
  libroAutor: { fontSize: 13, color: colores.textoSuave },
  libroCantidad: { fontSize: 15, fontWeight: '700', color: colores.primario },
  botones: { marginTop: 24, gap: 10 },
  nota: {
    marginTop: 20,
    color: colores.textoSuave,
    backgroundColor: colores.primarioSuave,
    padding: 12,
    borderRadius: 10,
    fontSize: 14,
  },
});
