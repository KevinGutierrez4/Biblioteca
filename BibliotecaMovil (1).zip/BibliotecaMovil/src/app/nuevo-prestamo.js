import { useCallback, useEffect, useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Boton from '../components/Boton';
import Campo from '../components/Campo';
import Selector from '../components/Selector';
import Tarjeta from '../components/Tarjeta';
import { Cargando, ErrorCarga, Vacio } from '../components/Estados';
import { librosApi, prestamosApi, usuariosApi } from '../api/servicios';
import { useAuth } from '../context/AuthContext';
import { avisar } from '../utils/confirmar';
import { colores } from '../theme';

const MAXIMO_POR_LIBRO = 100;

/**
 * Un préstamo puede incluir varios libros (relación N:M a través de DetallePrestamo).
 * El Administrador además elige a nombre de qué usuario se registra.
 */
export default function NuevoPrestamo() {
  const { idLibro } = useLocalSearchParams();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { esAdmin, usuario: yo } = useAuth();

  const [libros, setLibros] = useState([]);
  const [usuarios, setUsuarios] = useState([]);
  const [seleccion, setSeleccion] = useState({}); // { idLibro: cantidad }
  const [idUsuario, setIdUsuario] = useState(yo?.idUsuario);
  const [filtro, setFiltro] = useState('');
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');
  const [enviando, setEnviando] = useState(false);

  // Pide libros (y usuarios si es Administrador) y aplica la selección inicial.
  const cargar = useCallback(() => {
    return Promise.all([librosApi.listar(), esAdmin ? usuariosApi.listar() : Promise.resolve([])])
      .then(([listaLibros, listaUsuarios]) => {
        setError('');
        setLibros(listaLibros);
        setUsuarios(listaUsuarios);

        // Si se llegó desde el detalle de un libro, ya viene seleccionado.
        const inicial = listaLibros.find((l) => String(l.idLibro) === String(idLibro));
        if (inicial && inicial.cantidadDisponible > 0) {
          setSeleccion((actual) =>
            Object.keys(actual).length ? actual : { [inicial.idLibro]: 1 },
          );
        }
      })
      .catch((e) => setError(e.message))
      .finally(() => setCargando(false));
  }, [esAdmin, idLibro]);

  function reintentar() {
    setCargando(true);
    setError('');
    cargar();
  }

  useEffect(() => {
    cargar();
  }, [cargar]);

  const librosFiltrados = useMemo(() => {
    const t = filtro.trim().toLowerCase();
    if (!t) return libros;
    return libros.filter(
      (l) => l.titulo.toLowerCase().includes(t) || l.autor.toLowerCase().includes(t),
    );
  }, [libros, filtro]);

  const opcionesUsuario = useMemo(
    () =>
      usuarios.map((u) => ({
        valor: u.idUsuario,
        texto: u.idUsuario === yo?.idUsuario ? `${u.nombre} (yo)` : u.nombre,
      })),
    [usuarios, yo],
  );

  const totalLibros = Object.values(seleccion).reduce((s, c) => s + c, 0);

  function cambiarCantidad(libro, delta) {
    setSeleccion((actual) => {
      const maximo = Math.min(libro.cantidadDisponible, MAXIMO_POR_LIBRO);
      const nueva = Math.max(0, Math.min(maximo, (actual[libro.idLibro] ?? 0) + delta));
      const copia = { ...actual };
      if (nueva === 0) delete copia[libro.idLibro];
      else copia[libro.idLibro] = nueva;
      return copia;
    });
  }

  async function confirmarPrestamo() {
    const detalles = Object.entries(seleccion).map(([id, cantidad]) => ({
      idLibro: Number(id),
      cantidad,
    }));
    if (detalles.length === 0) return;

    setEnviando(true);
    try {
      const creado = await prestamosApi.crear(detalles, esAdmin ? idUsuario : undefined);
      router.replace(`/prestamo/${creado.idPrestamo}`);
    } catch (e) {
      setEnviando(false);
      avisar('No se pudo registrar el préstamo', e.message);
      // El stock pudo cambiar: se recarga la lista.
      if (e.status === 409) reintentar();
    }
  }

  if (cargando) return <Cargando />;
  if (error) return <ErrorCarga mensaje={error} onReintentar={reintentar} />;

  return (
    <View style={styles.pantalla}>
      <FlatList
        data={librosFiltrados}
        keyExtractor={(l) => String(l.idLibro)}
        contentContainerStyle={styles.lista}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View>
            {esAdmin && opcionesUsuario.length > 0 ? (
              <View style={styles.bloque}>
                <Text style={styles.etiqueta}>Registrar a nombre de</Text>
                <Selector opciones={opcionesUsuario} valor={idUsuario} onCambiar={setIdUsuario} />
              </View>
            ) : null}
            <Text style={styles.etiqueta}>Elige los libros</Text>
            <Campo
              value={filtro}
              onChangeText={setFiltro}
              placeholder="Filtrar por título o autor"
            />
          </View>
        }
        ListEmptyComponent={<Vacio icono="book-outline" texto="No hay libros." />}
        renderItem={({ item }) => {
          const cantidad = seleccion[item.idLibro] ?? 0;
          const agotado = item.cantidadDisponible === 0;
          return (
            <Tarjeta estilo={[cantidad > 0 && styles.seleccionada, agotado && styles.agotada]}>
              <View style={styles.fila}>
                <View style={styles.info}>
                  <Text style={styles.titulo} numberOfLines={2}>
                    {item.titulo}
                  </Text>
                  <Text style={styles.autor}>{item.autor}</Text>
                  <Text style={[styles.disp, agotado && { color: colores.peligro }]}>
                    {agotado ? 'Agotado' : `${item.cantidadDisponible} disponibles`}
                  </Text>
                </View>
                <View style={styles.contador}>
                  <BotonCantidad
                    icono="remove"
                    deshabilitado={cantidad === 0}
                    onPress={() => cambiarCantidad(item, -1)}
                  />
                  <Text style={styles.cantidad}>{cantidad}</Text>
                  <BotonCantidad
                    icono="add"
                    deshabilitado={
                      agotado || cantidad >= Math.min(item.cantidadDisponible, MAXIMO_POR_LIBRO)
                    }
                    onPress={() => cambiarCantidad(item, 1)}
                  />
                </View>
              </View>
            </Tarjeta>
          );
        }}
      />

      <View style={[styles.barra, { paddingBottom: insets.bottom + 12 }]}>
        <Text style={styles.resumen}>
          {totalLibros === 0
            ? 'Ningún libro seleccionado'
            : `${totalLibros} ${totalLibros === 1 ? 'libro seleccionado' : 'libros seleccionados'}`}
        </Text>
        <Boton
          titulo="Confirmar préstamo"
          icono="checkmark-circle-outline"
          onPress={confirmarPrestamo}
          deshabilitado={totalLibros === 0}
          cargando={enviando}
        />
      </View>
    </View>
  );
}

function BotonCantidad({ icono, onPress, deshabilitado }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={deshabilitado}
      hitSlop={6}
      style={[styles.botonCantidad, deshabilitado && { opacity: 0.35 }]}
    >
      <Ionicons name={icono} size={20} color={colores.primario} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  pantalla: { flex: 1, backgroundColor: colores.fondo },
  lista: { padding: 16, paddingBottom: 24 },
  bloque: { marginBottom: 16 },
  etiqueta: { fontSize: 14, fontWeight: '700', color: colores.texto, marginBottom: 8 },
  seleccionada: { borderColor: colores.primario, borderWidth: 2 },
  agotada: { opacity: 0.6 },
  fila: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  info: { flex: 1 },
  titulo: { fontSize: 15, fontWeight: '700', color: colores.texto },
  autor: { fontSize: 13, color: colores.textoSuave, marginTop: 2 },
  disp: { fontSize: 12, color: colores.exito, marginTop: 4, fontWeight: '600' },
  contador: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  botonCantidad: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: colores.primario,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cantidad: {
    minWidth: 24,
    textAlign: 'center',
    fontSize: 17,
    fontWeight: '700',
    color: colores.texto,
  },
  barra: {
    paddingHorizontal: 16,
    paddingTop: 12,
    backgroundColor: colores.tarjeta,
    borderTopWidth: 1,
    borderTopColor: colores.borde,
    gap: 8,
  },
  resumen: { color: colores.textoSuave, fontSize: 14, textAlign: 'center' },
});
