import { Redirect } from 'expo-router';
import { useAuth } from '../context/AuthContext';

export default function Inicio() {
  const { sesion } = useAuth();
  return <Redirect href={sesion ? '/libros' : '/login'} />;
}
