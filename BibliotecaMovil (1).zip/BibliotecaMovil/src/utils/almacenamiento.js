import { Platform } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';

// En el celular el token se guarda cifrado (SecureStore).
// En la web (expo start --web) SecureStore no existe, así que se usa AsyncStorage.
const esWeb = Platform.OS === 'web';

export async function leerSeguro(clave) {
  try {
    return esWeb ? await AsyncStorage.getItem(clave) : await SecureStore.getItemAsync(clave);
  } catch {
    return null;
  }
}

export async function guardarSeguro(clave, valor) {
  try {
    if (esWeb) await AsyncStorage.setItem(clave, valor);
    else await SecureStore.setItemAsync(clave, valor);
  } catch {
    // La sesión sigue en memoria aunque no se pueda guardar.
  }
}

export async function borrarSeguro(clave) {
  try {
    if (esWeb) await AsyncStorage.removeItem(clave);
    else await SecureStore.deleteItemAsync(clave);
  } catch {
    // Sin acción.
  }
}
