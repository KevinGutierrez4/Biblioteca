# BibliotecaAPI

API REST (ASP.NET Core 10 + EF Core + SQL Server + JWT) para el Proyecto Final Unidad 3.
La consumen un cliente web (React) y una app móvil (Android).

## Cómo ejecutarla

1. Abre `BibliotecaAPI.slnx` en Visual Studio y ejecuta el perfil **http**.
2. Al arrancar, la API **aplica las migraciones sola** y crea:
   - Administrador: `admin@biblioteca.com` / `Admin12345` (se cambia en `appsettings.json` → `AdminInicial`).
   - 5 libros de ejemplo si la tabla `Libros` está vacía.
3. Swagger: http://localhost:5120/swagger
   Haz login en `POST /api/auth/login`, copia el `token`, pulsa **Authorize** y pégalo.

## Modelo de datos (4 tablas)

| Tabla | Relación |
|---|---|
| Usuarios | 1:N con Prestamos |
| Prestamos | 1:N con DetallesPrestamo |
| Libros | 1:N con DetallesPrestamo |
| DetallesPrestamo | Tabla intermedia de la relación **N:M Prestamo ↔ Libro** (con atributo `Cantidad`) |

## Endpoints

| Método | Ruta | Acceso |
|---|---|---|
| POST | /api/auth/register | Público |
| POST | /api/auth/login | Público |
| GET | /api/usuarios/me | Autenticado |
| GET | /api/usuarios, /api/usuarios/{id} | Administrador |
| PUT | /api/usuarios/{id} (nombre, correo, rol) | Administrador |
| DELETE | /api/usuarios/{id} | Administrador |
| GET | /api/libros?buscar=, /api/libros/{id} | Autenticado |
| POST / PUT / DELETE | /api/libros | Administrador |
| GET | /api/prestamos?estado=&idUsuario= , /api/prestamos/{id} | Usuario: solo los suyos · Admin: todos |
| POST | /api/prestamos | Autenticado (Usuario: a su nombre · Admin: puede indicar `idUsuario`) |
| PUT | /api/prestamos/{id} (`estado`: Activo / Devuelto) | Administrador |
| DELETE | /api/prestamos/{id} | Administrador |

### Reglas de negocio
- Al crear un préstamo se valida y **descuenta el stock** (`CantidadDisponible`); si no alcanza → 409.
- Al marcar **Devuelto** se guarda `FechaDevolucion` y el stock vuelve; al reactivar se descuenta otra vez.
- Al eliminar un préstamo activo, el stock vuelve.
- `CantidadDisponible` es token de concurrencia: dos préstamos simultáneos no pueden dejar stock negativo.
- No se puede borrar un libro o usuario con historial de préstamos.
- El registro público siempre crea rol `Usuario`; solo un Administrador puede asignar roles.

## Conectar los clientes

**React (web):** los orígenes permitidos por CORS están en `appsettings.json` → `Cors:OrigenesPermitidos`
(por defecto `http://localhost:5173` de Vite y `http://localhost:3000`). Agrega el tuyo si usas otro puerto.

**Android:**
- Emulador: usa `http://10.0.2.2:5120/` con el perfil **http**.
- Celular físico: ejecuta el perfil **http-celular** (escucha en todas las interfaces) y usa
  `http://<IP-de-tu-PC>:5120/`. El celular y la PC deben estar en la misma red Wi-Fi; si no conecta,
  permite el puerto 5120 en el Firewall de Windows.
- Como en desarrollo se usa HTTP, en el `AndroidManifest.xml` agrega
  `android:usesCleartextTraffic="true"` dentro de `<application>`.
- Envía el token en cada petición: `Authorization: Bearer <token>`.

## Si ya tenías la base de datos creada
No hace falta hacer nada: al iniciar se aplica la migración `AjustesUsuarioYStock`
(limita `Rol` a 20 caracteres y `PasswordHash` a 500). También puedes aplicarla con `Update-Database`.
