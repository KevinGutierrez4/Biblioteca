using System.ComponentModel.DataAnnotations;

namespace BibliotecaAPI.Models;

/// <summary>
/// Tabla intermedia de la relación N:M entre Prestamo y Libro.
/// Un préstamo incluye muchos libros y un libro aparece en muchos préstamos.
/// </summary>
public class DetallePrestamo
{
    [Key]
    public int IdDetalle { get; set; }

    public int IdPrestamo { get; set; }

    public int IdLibro { get; set; }

    [Range(1, 100)]
    public int Cantidad { get; set; }

    public Prestamo? Prestamo { get; set; }

    public Libro? Libro { get; set; }
}
