
using System.ComponentModel.DataAnnotations;

namespace BibliotecaAPI.Models;

public class Libro
{
    [Key]
    public int IdLibro { get; set; }

    [Required, MaxLength(150)]
    public string Titulo { get; set; } = string.Empty;

    [Required, MaxLength(100)]
    public string Autor { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string ISBN { get; set; } = string.Empty;

    // ConcurrencyCheck evita que dos préstamos simultáneos descuenten el mismo stock.
    [Range(0, 10000), ConcurrencyCheck]
    public int CantidadDisponible { get; set; }

    public ICollection<DetallePrestamo> Detalles { get; set; }
        = new List<DetallePrestamo>();
}
