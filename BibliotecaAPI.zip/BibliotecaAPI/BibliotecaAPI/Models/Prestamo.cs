using System.ComponentModel.DataAnnotations;
using BibliotecaAPI.Common;

namespace BibliotecaAPI.Models;

public class Prestamo
{
    public int IdPrestamo { get; set; }

    public int IdUsuario { get; set; }

    public DateTime FechaPrestamo { get; set; } = DateTime.UtcNow;

    public DateTime? FechaDevolucion { get; set; }

    [Required, MaxLength(20)]
    public string Estado { get; set; } = EstadosPrestamo.Activo;

    public Usuario? Usuario { get; set; }

    public ICollection<DetallePrestamo> Detalles { get; set; }
        = new List<DetallePrestamo>();
}
