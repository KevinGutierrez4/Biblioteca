using System.ComponentModel.DataAnnotations;
using BibliotecaAPI.Common;

namespace BibliotecaAPI.Models;

public class Usuario
{
    public int IdUsuario { get; set; }

    [Required, MaxLength(100)]
    public string Nombre { get; set; } = string.Empty;

    [Required, EmailAddress, MaxLength(150)]
    public string Correo { get; set; } = string.Empty;

    [Required, MaxLength(500)]
    public string PasswordHash { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string Rol { get; set; } = Roles.Usuario;

    public ICollection<Prestamo> Prestamos { get; set; }
        = new List<Prestamo>();
}
