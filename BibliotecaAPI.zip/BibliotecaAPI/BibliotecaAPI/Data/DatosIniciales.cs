using BibliotecaAPI.Common;
using BibliotecaAPI.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace BibliotecaAPI.Data;

/// <summary>
/// Aplica las migraciones pendientes y crea los datos mínimos para usar la API:
/// un usuario Administrador (configurado en appsettings: "AdminInicial")
/// y algunos libros de ejemplo si la tabla está vacía.
/// </summary>
public static class DatosIniciales
{
    public static async Task InicializarAsync(IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var sp = scope.ServiceProvider;

        var db = sp.GetRequiredService<BibliotecaContext>();
        var config = sp.GetRequiredService<IConfiguration>();
        var hasher = sp.GetRequiredService<IPasswordHasher<Usuario>>();
        var logger = sp.GetRequiredService<ILoggerFactory>()
            .CreateLogger("DatosIniciales");

        await db.Database.MigrateAsync();

        // ---------- Administrador inicial ----------
        var correo = config["AdminInicial:Correo"]?.Trim().ToLowerInvariant();
        var password = config["AdminInicial:Password"];
        var nombre = config["AdminInicial:Nombre"] ?? "Administrador";

        if (!string.IsNullOrWhiteSpace(correo) && !string.IsNullOrWhiteSpace(password))
        {
            var admin = await db.Usuarios.FirstOrDefaultAsync(u => u.Correo == correo);

            if (admin == null)
            {
                admin = new Usuario
                {
                    Nombre = nombre,
                    Correo = correo,
                    Rol = Roles.Administrador
                };
                admin.PasswordHash = hasher.HashPassword(admin, password);
                db.Usuarios.Add(admin);

                logger.LogInformation("Administrador inicial creado: {Correo}", correo);
            }
            else if (admin.Rol != Roles.Administrador)
            {
                admin.Rol = Roles.Administrador;
                logger.LogInformation("Usuario {Correo} promovido a Administrador", correo);
            }
        }

        // ---------- Libros de ejemplo ----------
        if (!await db.Libros.AnyAsync())
        {
            db.Libros.AddRange(
                new Libro { Titulo = "Cien años de soledad", Autor = "Gabriel García Márquez", ISBN = "DEMO-0001", CantidadDisponible = 5 },
                new Libro { Titulo = "Don Quijote de la Mancha", Autor = "Miguel de Cervantes", ISBN = "DEMO-0002", CantidadDisponible = 3 },
                new Libro { Titulo = "Raza de bronce", Autor = "Alcides Arguedas", ISBN = "DEMO-0003", CantidadDisponible = 4 },
                new Libro { Titulo = "Clean Code", Autor = "Robert C. Martin", ISBN = "DEMO-0004", CantidadDisponible = 2 },
                new Libro { Titulo = "El principito", Autor = "Antoine de Saint-Exupéry", ISBN = "DEMO-0005", CantidadDisponible = 6 });

            logger.LogInformation("Se agregaron libros de ejemplo.");
        }

        await db.SaveChangesAsync();
    }
}
