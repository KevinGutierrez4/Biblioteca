
using BibliotecaAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace BibliotecaAPI.Data
{
    public class BibliotecaContext : DbContext
    {
        public BibliotecaContext(
            DbContextOptions<BibliotecaContext> options)
            : base(options)
        {
        }

        // Tablas de la base de datos
        public DbSet<Usuario> Usuarios => Set<Usuario>();
        public DbSet<Libro> Libros => Set<Libro>();
        public DbSet<Prestamo> Prestamos => Set<Prestamo>();
        public DbSet<DetallePrestamo> DetallesPrestamo
            => Set<DetallePrestamo>();

        protected override void OnModelCreating(
            ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Claves primarias
            modelBuilder.Entity<Usuario>()
                .HasKey(u => u.IdUsuario);

            modelBuilder.Entity<Libro>()
                .HasKey(l => l.IdLibro);

            modelBuilder.Entity<Prestamo>()
                .HasKey(p => p.IdPrestamo);

            modelBuilder.Entity<DetallePrestamo>()
                .HasKey(d => d.IdDetalle);

            // El correo del usuario debe ser único
            modelBuilder.Entity<Usuario>()
                .HasIndex(u => u.Correo)
                .IsUnique();

            // El ISBN del libro debe ser único
            modelBuilder.Entity<Libro>()
                .HasIndex(l => l.ISBN)
                .IsUnique();

            // Relación: Usuario 1 - N Préstamos
            modelBuilder.Entity<Prestamo>()
                .HasOne(p => p.Usuario)
                .WithMany(u => u.Prestamos)
                .HasForeignKey(p => p.IdUsuario)
                .OnDelete(DeleteBehavior.Restrict);

            // Relación: Préstamo 1 - N Detalles
            modelBuilder.Entity<DetallePrestamo>()
                .HasOne(d => d.Prestamo)
                .WithMany(p => p.Detalles)
                .HasForeignKey(d => d.IdPrestamo)
                .OnDelete(DeleteBehavior.Cascade);

            // Relación: Libro 1 - N Detalles
            modelBuilder.Entity<DetallePrestamo>()
                .HasOne(d => d.Libro)
                .WithMany(l => l.Detalles)
                .HasForeignKey(d => d.IdLibro)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
