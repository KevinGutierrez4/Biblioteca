using System.Security.Claims;

namespace BibliotecaAPI.Common;

public static class ClaimsPrincipalExtensions
{
    /// <summary>Devuelve el IdUsuario guardado en el token JWT.</summary>
    public static int ObtenerIdUsuario(this ClaimsPrincipal user)
    {
        var valor = user.FindFirstValue(ClaimTypes.NameIdentifier);

        return int.TryParse(valor, out var id)
            ? id
            : throw new InvalidOperationException(
                "El token no contiene el identificador del usuario.");
    }

    public static bool EsAdministrador(this ClaimsPrincipal user)
        => user.IsInRole(Roles.Administrador);
}
