namespace BibliotecaAPI.Common;

public static class Roles
{
    public const string Administrador = "Administrador";
    public const string Usuario = "Usuario";

    public static readonly string[] Todos = [Administrador, Usuario];
}

public static class EstadosPrestamo
{
    public const string Activo = "Activo";
    public const string Devuelto = "Devuelto";

    public static readonly string[] Todos = [Activo, Devuelto];
}
