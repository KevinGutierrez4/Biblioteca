using BibliotecaAPI.Common;
using BibliotecaAPI.Data;
using BibliotecaAPI.DTOs;
using BibliotecaAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BibliotecaAPI.Controllers;

[ApiController]
[Route("api/libros")]
[Authorize]
public class LibrosController : ControllerBase
{
    private readonly BibliotecaContext _context;

    public LibrosController(BibliotecaContext context)
    {
        _context = context;
    }

    // GET: api/libros?buscar=texto
    [HttpGet]
    public async Task<ActionResult<List<LibroDto>>> GetAll(
        [FromQuery] string? buscar)
    {
        var query = _context.Libros.AsNoTracking();

        if (!string.IsNullOrWhiteSpace(buscar))
        {
            var texto = buscar.Trim();
            query = query.Where(l =>
                l.Titulo.Contains(texto) ||
                l.Autor.Contains(texto) ||
                l.ISBN.Contains(texto));
        }

        var libros = await query
            .OrderBy(l => l.Titulo)
            .Select(l => new LibroDto
            {
                IdLibro = l.IdLibro,
                Titulo = l.Titulo,
                Autor = l.Autor,
                ISBN = l.ISBN,
                CantidadDisponible = l.CantidadDisponible
            })
            .ToListAsync();

        return Ok(libros);
    }

    // GET: api/libros/5
    [HttpGet("{id:int}")]
    public async Task<ActionResult<LibroDto>> GetById(int id)
    {
        var libro = await _context.Libros
            .AsNoTracking()
            .FirstOrDefaultAsync(l => l.IdLibro == id);

        if (libro == null)
            return NotFound(new { mensaje = "Libro no encontrado." });

        return Ok(ADto(libro));
    }

    // POST: api/libros
    [HttpPost]
    [Authorize(Roles = Roles.Administrador)]
    public async Task<ActionResult<LibroDto>> Create(LibroGuardarDto dto)
    {
        var isbn = dto.ISBN.Trim();

        if (await _context.Libros.AnyAsync(l => l.ISBN == isbn))
            return Conflict(new { mensaje = "El ISBN ya existe." });

        var libro = new Libro
        {
            Titulo = dto.Titulo.Trim(),
            Autor = dto.Autor.Trim(),
            ISBN = isbn,
            CantidadDisponible = dto.CantidadDisponible
        };

        _context.Libros.Add(libro);
        await _context.SaveChangesAsync();

        return CreatedAtAction(
            nameof(GetById),
            new { id = libro.IdLibro },
            ADto(libro));
    }

    // PUT: api/libros/5
    [HttpPut("{id:int}")]
    [Authorize(Roles = Roles.Administrador)]
    public async Task<ActionResult<LibroDto>> Update(int id, LibroGuardarDto dto)
    {
        var libro = await _context.Libros.FindAsync(id);

        if (libro == null)
            return NotFound(new { mensaje = "Libro no encontrado." });

        var isbn = dto.ISBN.Trim();

        if (await _context.Libros.AnyAsync(
            l => l.ISBN == isbn && l.IdLibro != id))
            return Conflict(new { mensaje = "El ISBN ya pertenece a otro libro." });

        libro.Titulo = dto.Titulo.Trim();
        libro.Autor = dto.Autor.Trim();
        libro.ISBN = isbn;
        libro.CantidadDisponible = dto.CantidadDisponible;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            return Conflict(new
            {
                mensaje = "El stock del libro cambió mientras lo editabas. Vuelve a cargarlo."
            });
        }

        return Ok(ADto(libro));
    }

    // DELETE: api/libros/5
    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Administrador)]
    public async Task<IActionResult> Delete(int id)
    {
        var libro = await _context.Libros.FindAsync(id);

        if (libro == null)
            return NotFound(new { mensaje = "Libro no encontrado." });

        var tieneHistorial = await _context.DetallesPrestamo
            .AnyAsync(d => d.IdLibro == id);

        if (tieneHistorial)
            return Conflict(new
            {
                mensaje = "No se puede eliminar un libro que tiene historial de préstamos."
            });

        _context.Libros.Remove(libro);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private static LibroDto ADto(Libro l) => new()
    {
        IdLibro = l.IdLibro,
        Titulo = l.Titulo,
        Autor = l.Autor,
        ISBN = l.ISBN,
        CantidadDisponible = l.CantidadDisponible
    };
}
