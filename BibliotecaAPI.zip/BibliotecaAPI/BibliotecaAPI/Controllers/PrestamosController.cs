using System.Linq.Expressions;
using BibliotecaAPI.Common;
using BibliotecaAPI.Data;
using BibliotecaAPI.DTOs;
using BibliotecaAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BibliotecaAPI.Controllers;

[ApiController]
[Route("api/prestamos")]
[Authorize]
public class PrestamosController : ControllerBase
{
    private readonly BibliotecaContext _context;

    public PrestamosController(BibliotecaContext context)
    {
        _context = context;
    }

    // Convierte la entidad en un DTO plano: sin ciclos y sin datos sensibles (PasswordHash).
    private static readonly Expression<Func<Prestamo, PrestamoDto>> AProyeccion =
        p => new PrestamoDto
        {
            IdPrestamo = p.IdPrestamo,
            FechaPrestamo = p.FechaPrestamo,
            FechaDevolucion = p.FechaDevolucion,
            Estado = p.Estado,
            Usuario = new UsuarioResumenDto
            {
                IdUsuario = p.Usuario!.IdUsuario,
                Nombre = p.Usuario.Nombre,
                Correo = p.Usuario.Correo
            },
            Detalles = p.Detalles
                .Select(d => new DetallePrestamoDto
                {
                    IdDetalle = d.IdDetalle,
                    IdLibro = d.IdLibro,
                    Titulo = d.Libro!.Titulo,
                    Autor = d.Libro.Autor,
                    Cantidad = d.Cantidad
                })
                .ToList()
        };

    // GET: api/prestamos?estado=Activo&idUsuario=3
    // Administrador: ve todos (puede filtrar por usuario). Usuario: solo los suyos.
    [HttpGet]
    public async Task<ActionResult<List<PrestamoDto>>> ObtenerPrestamos(
        [FromQuery] string? estado,
        [FromQuery] int? idUsuario)
    {
        var query = _context.Prestamos.AsNoTracking();

        if (User.EsAdministrador())
        {
            if (idUsuario is > 0)
                query = query.Where(p => p.IdUsuario == idUsuario);
        }
        else
        {
            var miId = User.ObtenerIdUsuario();
            query = query.Where(p => p.IdUsuario == miId);
        }

        if (!string.IsNullOrWhiteSpace(estado))
        {
            var estadoValido = NormalizarEstado(estado);
            if (estadoValido == null)
                return BadRequest(new { mensaje = MensajeEstadoInvalido });

            query = query.Where(p => p.Estado == estadoValido);
        }

        var prestamos = await query
            .OrderByDescending(p => p.FechaPrestamo)
            .Select(AProyeccion)
            .ToListAsync();

        return Ok(prestamos);
    }

    // GET: api/prestamos/5
    [HttpGet("{id:int}")]
    public async Task<ActionResult<PrestamoDto>> ObtenerPrestamo(int id)
    {
        var prestamo = await ObtenerDtoAsync(id);

        if (prestamo == null)
            return NotFound(new { mensaje = "Préstamo no encontrado." });

        if (!User.EsAdministrador() &&
            prestamo.Usuario.IdUsuario != User.ObtenerIdUsuario())
            return Forbid();

        return Ok(prestamo);
    }

    // POST: api/prestamos
    // Usuario: el préstamo se registra a su nombre (se toma del token).
    // Administrador: puede indicar IdUsuario para registrarlo a nombre de otro.
    [HttpPost]
    public async Task<ActionResult<PrestamoDto>> CrearPrestamo(PrestamoCrearDto dto)
    {
        var idUsuario = User.ObtenerIdUsuario();

        if (User.EsAdministrador() && dto.IdUsuario is > 0)
            idUsuario = dto.IdUsuario.Value;

        if (!await _context.Usuarios.AnyAsync(u => u.IdUsuario == idUsuario))
            return BadRequest(new { mensaje = "El usuario indicado no existe." });

        // Si el mismo libro viene repetido, se suman las cantidades.
        var pedidos = dto.Detalles
            .GroupBy(d => d.IdLibro)
            .Select(g => new { IdLibro = g.Key, Cantidad = g.Sum(x => x.Cantidad) })
            .ToList();

        var ids = pedidos.Select(p => p.IdLibro).ToList();

        var libros = await _context.Libros
            .Where(l => ids.Contains(l.IdLibro))
            .ToDictionaryAsync(l => l.IdLibro);

        foreach (var pedido in pedidos)
        {
            if (!libros.TryGetValue(pedido.IdLibro, out var libro))
                return BadRequest(new
                {
                    mensaje = $"El libro con ID {pedido.IdLibro} no existe."
                });

            if (pedido.Cantidad > 100)
                return BadRequest(new
                {
                    mensaje = "La cantidad debe estar entre 1 y 100."
                });

            if (libro.CantidadDisponible < pedido.Cantidad)
                return Conflict(new
                {
                    mensaje = $"Stock insuficiente para \"{libro.Titulo}\". " +
                              $"Disponibles: {libro.CantidadDisponible}."
                });
        }

        var prestamo = new Prestamo
        {
            IdUsuario = idUsuario,
            FechaPrestamo = DateTime.UtcNow,
            Estado = EstadosPrestamo.Activo
        };

        foreach (var pedido in pedidos)
        {
            libros[pedido.IdLibro].CantidadDisponible -= pedido.Cantidad;

            prestamo.Detalles.Add(new DetallePrestamo
            {
                IdLibro = pedido.IdLibro,
                Cantidad = pedido.Cantidad
            });
        }

        _context.Prestamos.Add(prestamo);

        if (!await GuardarCambiosAsync())
            return ConflictoDeStock();

        var resultado = await ObtenerDtoAsync(prestamo.IdPrestamo);

        return CreatedAtAction(
            nameof(ObtenerPrestamo),
            new { id = prestamo.IdPrestamo },
            resultado);
    }

    // PUT: api/prestamos/5   body: { "estado": "Devuelto" }
    // Al pasar a "Devuelto" se registra la fecha y se devuelve el stock.
    // Al reactivar ("Activo") se vuelve a descontar el stock.
    [HttpPut("{id:int}")]
    [Authorize(Roles = Roles.Administrador)]
    public async Task<ActionResult<PrestamoDto>> ActualizarPrestamo(
        int id, PrestamoActualizarDto dto)
    {
        var nuevoEstado = NormalizarEstado(dto.Estado);

        if (nuevoEstado == null)
            return BadRequest(new { mensaje = MensajeEstadoInvalido });

        var prestamo = await _context.Prestamos
            .Include(p => p.Detalles)
                .ThenInclude(d => d.Libro)
            .FirstOrDefaultAsync(p => p.IdPrestamo == id);

        if (prestamo == null)
            return NotFound(new { mensaje = "Préstamo no encontrado." });

        if (prestamo.Estado != nuevoEstado)
        {
            if (nuevoEstado == EstadosPrestamo.Devuelto)
            {
                foreach (var detalle in prestamo.Detalles)
                    detalle.Libro!.CantidadDisponible += detalle.Cantidad;

                prestamo.FechaDevolucion = DateTime.UtcNow;
            }
            else
            {
                foreach (var detalle in prestamo.Detalles)
                {
                    if (detalle.Libro!.CantidadDisponible < detalle.Cantidad)
                        return Conflict(new
                        {
                            mensaje = $"No hay stock suficiente de \"{detalle.Libro.Titulo}\" " +
                                      "para reactivar el préstamo."
                        });
                }

                foreach (var detalle in prestamo.Detalles)
                    detalle.Libro!.CantidadDisponible -= detalle.Cantidad;

                prestamo.FechaDevolucion = null;
            }

            prestamo.Estado = nuevoEstado;

            if (!await GuardarCambiosAsync())
                return ConflictoDeStock();
        }

        return Ok(await ObtenerDtoAsync(id));
    }

    // DELETE: api/prestamos/5
    // Si el préstamo seguía activo, los libros vuelven al stock.
    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Administrador)]
    public async Task<IActionResult> EliminarPrestamo(int id)
    {
        var prestamo = await _context.Prestamos
            .Include(p => p.Detalles)
                .ThenInclude(d => d.Libro)
            .FirstOrDefaultAsync(p => p.IdPrestamo == id);

        if (prestamo == null)
            return NotFound(new { mensaje = "Préstamo no encontrado." });

        if (prestamo.Estado == EstadosPrestamo.Activo)
        {
            foreach (var detalle in prestamo.Detalles)
                detalle.Libro!.CantidadDisponible += detalle.Cantidad;
        }

        _context.Prestamos.Remove(prestamo);

        if (!await GuardarCambiosAsync())
            return ConflictoDeStock();

        return NoContent();
    }

    // ----------------- Auxiliares -----------------

    private const string MensajeEstadoInvalido =
        "El estado debe ser \"Activo\" o \"Devuelto\".";

    private static string? NormalizarEstado(string estado)
        => EstadosPrestamo.Todos.FirstOrDefault(e =>
            string.Equals(e, estado.Trim(), StringComparison.OrdinalIgnoreCase));

    private Task<PrestamoDto?> ObtenerDtoAsync(int id)
        => _context.Prestamos
            .AsNoTracking()
            .Where(p => p.IdPrestamo == id)
            .Select(AProyeccion)
            .FirstOrDefaultAsync();

    /// <summary>
    /// Guarda los cambios. Devuelve false si otro préstamo modificó el stock
    /// de algún libro al mismo tiempo (control de concurrencia optimista).
    /// </summary>
    private async Task<bool> GuardarCambiosAsync()
    {
        try
        {
            await _context.SaveChangesAsync();
            return true;
        }
        catch (DbUpdateConcurrencyException)
        {
            return false;
        }
    }

    private ConflictObjectResult ConflictoDeStock()
        => Conflict(new
        {
            mensaje = "El stock de un libro cambió mientras se procesaba la operación. " +
                      "Inténtalo de nuevo."
        });
}
