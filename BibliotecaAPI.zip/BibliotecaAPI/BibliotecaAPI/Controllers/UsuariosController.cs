using BibliotecaAPI.Common;
using BibliotecaAPI.Data;
using BibliotecaAPI.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BibliotecaAPI.Controllers;

[ApiController]
[Route("api/usuarios")]
[Authorize]
public class UsuariosController : ControllerBase
{
    private readonly BibliotecaContext _context;

    public UsuariosController(BibliotecaContext context)
    {
        _context = context;
    }

    // GET: api/usuarios/me  (cualquier usuario autenticado)
    [HttpGet("me")]
    public async Task<ActionResult<UsuarioDto>> Me()
    {
        var id = User.ObtenerIdUsuario();
        var usuario = await BuscarDtoAsync(id);

        if (usuario == null)
            return NotFound(new { mensaje = "Usuario no encontrado." });

        return Ok(usuario);
    }

    // GET: api/usuarios
    [HttpGet]
    [Authorize(Roles = Roles.Administrador)]
    public async Task<ActionResult<List<UsuarioDto>>> GetAll()
    {
        var usuarios = await _context.Usuarios
            .AsNoTracking()
            .OrderBy(u => u.Nombre)
            .Select(u => new UsuarioDto
            {
                IdUsuario = u.IdUsuario,
                Nombre = u.Nombre,
                Correo = u.Correo,
                Rol = u.Rol
            })
            .ToListAsync();

        return Ok(usuarios);
    }

    // GET: api/usuarios/5
    [HttpGet("{id:int}")]
    [Authorize(Roles = Roles.Administrador)]
    public async Task<ActionResult<UsuarioDto>> GetById(int id)
    {
        var usuario = await BuscarDtoAsync(id);

        if (usuario == null)
            return NotFound(new { mensaje = "Usuario no encontrado." });

        return Ok(usuario);
    }

    // PUT: api/usuarios/5  (editar datos y asignar rol)
    [HttpPut("{id:int}")]
    [Authorize(Roles = Roles.Administrador)]
    public async Task<ActionResult<UsuarioDto>> Update(int id, UsuarioActualizarDto dto)
    {
        var rol = Roles.Todos.FirstOrDefault(r =>
            string.Equals(r, dto.Rol.Trim(), StringComparison.OrdinalIgnoreCase));

        if (rol == null)
            return BadRequest(new
            {
                mensaje = "El rol debe ser \"Administrador\" o \"Usuario\"."
            });

        var usuario = await _context.Usuarios.FindAsync(id);

        if (usuario == null)
            return NotFound(new { mensaje = "Usuario no encontrado." });

        // Evita que el administrador se quite su propio rol y se quede sin acceso.
        if (id == User.ObtenerIdUsuario() && rol != Roles.Administrador)
            return BadRequest(new
            {
                mensaje = "No puedes quitarte tu propio rol de Administrador."
            });

        var correo = dto.Correo.Trim().ToLowerInvariant();

        if (await _context.Usuarios.AnyAsync(
            u => u.Correo == correo && u.IdUsuario != id))
            return Conflict(new { mensaje = "El correo ya pertenece a otro usuario." });

        usuario.Nombre = dto.Nombre.Trim();
        usuario.Correo = correo;
        usuario.Rol = rol;

        await _context.SaveChangesAsync();

        return Ok(new UsuarioDto
        {
            IdUsuario = usuario.IdUsuario,
            Nombre = usuario.Nombre,
            Correo = usuario.Correo,
            Rol = usuario.Rol
        });
    }

    // DELETE: api/usuarios/5
    [HttpDelete("{id:int}")]
    [Authorize(Roles = Roles.Administrador)]
    public async Task<IActionResult> Delete(int id)
    {
        if (id == User.ObtenerIdUsuario())
            return BadRequest(new { mensaje = "No puedes eliminar tu propia cuenta." });

        var usuario = await _context.Usuarios.FindAsync(id);

        if (usuario == null)
            return NotFound(new { mensaje = "Usuario no encontrado." });

        var tieneHistorial = await _context.Prestamos
            .AnyAsync(p => p.IdUsuario == id);

        if (tieneHistorial)
            return Conflict(new
            {
                mensaje = "No se puede eliminar un usuario con historial de préstamos."
            });

        _context.Usuarios.Remove(usuario);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private Task<UsuarioDto?> BuscarDtoAsync(int id)
        => _context.Usuarios
            .AsNoTracking()
            .Where(u => u.IdUsuario == id)
            .Select(u => new UsuarioDto
            {
                IdUsuario = u.IdUsuario,
                Nombre = u.Nombre,
                Correo = u.Correo,
                Rol = u.Rol
            })
            .FirstOrDefaultAsync();
}
