using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BibliotecaAPI.Common;
using BibliotecaAPI.Data;
using BibliotecaAPI.DTOs;
using BibliotecaAPI.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace BibliotecaAPI.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly BibliotecaContext _context;
    private readonly IPasswordHasher<Usuario> _hasher;
    private readonly IConfiguration _configuration;

    public AuthController(
        BibliotecaContext context,
        IPasswordHasher<Usuario> hasher,
        IConfiguration configuration)
    {
        _context = context;
        _hasher = hasher;
        _configuration = configuration;
    }

    // POST: api/auth/register
    [HttpPost("register")]
    [ProducesResponseType<UsuarioDto>(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Register(RegistroDto dto)
    {
        var correo = dto.Correo.Trim().ToLowerInvariant();

        if (await _context.Usuarios.AnyAsync(u => u.Correo == correo))
            return Conflict(new { mensaje = "El correo ya está registrado." });

        // El registro público siempre crea usuarios normales.
        // Los administradores se crean con el seed o los asigna otro administrador.
        var usuario = new Usuario
        {
            Nombre = dto.Nombre.Trim(),
            Correo = correo,
            Rol = Roles.Usuario
        };

        usuario.PasswordHash = _hasher.HashPassword(usuario, dto.Password);

        _context.Usuarios.Add(usuario);
        await _context.SaveChangesAsync();

        return Created("/api/usuarios/me", ADto(usuario));
    }

    // POST: api/auth/login
    [HttpPost("login")]
    [ProducesResponseType<LoginRespuestaDto>(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> Login(LoginDto dto)
    {
        var correo = dto.Correo.Trim().ToLowerInvariant();

        var usuario = await _context.Usuarios
            .SingleOrDefaultAsync(u => u.Correo == correo);

        if (usuario == null)
            return Unauthorized(new { mensaje = "Credenciales incorrectas." });

        var resultado = _hasher.VerifyHashedPassword(
            usuario, usuario.PasswordHash, dto.Password);

        if (resultado == PasswordVerificationResult.Failed)
            return Unauthorized(new { mensaje = "Credenciales incorrectas." });

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, usuario.IdUsuario.ToString()),
            new Claim(ClaimTypes.Name, usuario.Nombre),
            new Claim(ClaimTypes.Email, usuario.Correo),
            new Claim(ClaimTypes.Role, usuario.Rol)
        };

        var key = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));

        var credentials = new SigningCredentials(
            key, SecurityAlgorithms.HmacSha256);

        var minutos = _configuration.GetValue("Jwt:ExpiracionMinutos", 60);

        var token = new JwtSecurityToken(
            issuer: _configuration["Jwt:Issuer"],
            audience: _configuration["Jwt:Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(minutos),
            signingCredentials: credentials);

        return Ok(new LoginRespuestaDto
        {
            Token = new JwtSecurityTokenHandler().WriteToken(token),
            Expiracion = token.ValidTo,
            Usuario = ADto(usuario)
        });
    }

    private static UsuarioDto ADto(Usuario u) => new()
    {
        IdUsuario = u.IdUsuario,
        Nombre = u.Nombre,
        Correo = u.Correo,
        Rol = u.Rol
    };
}
