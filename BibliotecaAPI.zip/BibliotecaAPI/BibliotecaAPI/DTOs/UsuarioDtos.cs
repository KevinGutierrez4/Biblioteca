using System.ComponentModel.DataAnnotations;

namespace BibliotecaAPI.DTOs;

public class UsuarioDto
{
    public int IdUsuario { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Correo { get; set; } = string.Empty;
    public string Rol { get; set; } = string.Empty;
}

public class UsuarioActualizarDto
{
    [Required, MaxLength(100)]
    public string Nombre { get; set; } = string.Empty;

    [Required, EmailAddress, MaxLength(150)]
    public string Correo { get; set; } = string.Empty;

    /// <summary>"Administrador" o "Usuario".</summary>
    [Required, MaxLength(20)]
    public string Rol { get; set; } = string.Empty;
}
