using System.ComponentModel.DataAnnotations;

namespace BibliotecaAPI.DTOs;

public class PrestamoDto
{
    public int IdPrestamo { get; set; }
    public DateTime FechaPrestamo { get; set; }
    public DateTime? FechaDevolucion { get; set; }
    public string Estado { get; set; } = string.Empty;
    public UsuarioResumenDto Usuario { get; set; } = new();
    public List<DetallePrestamoDto> Detalles { get; set; } = [];
}

public class UsuarioResumenDto
{
    public int IdUsuario { get; set; }
    public string Nombre { get; set; } = string.Empty;
    public string Correo { get; set; } = string.Empty;
}

public class DetallePrestamoDto
{
    public int IdDetalle { get; set; }
    public int IdLibro { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public string Autor { get; set; } = string.Empty;
    public int Cantidad { get; set; }
}

public class PrestamoCrearDto
{
    /// <summary>
    /// Solo lo usa el Administrador para registrar un préstamo a nombre de otro usuario.
    /// Para un usuario normal se ignora y se toma el usuario del token.
    /// </summary>
    public int? IdUsuario { get; set; }

    [Required, MinLength(1, ErrorMessage = "El préstamo debe contener al menos un libro.")]
    public List<DetallePrestamoCrearDto> Detalles { get; set; } = [];
}

public class DetallePrestamoCrearDto
{
    [Range(1, int.MaxValue, ErrorMessage = "Debes indicar un libro válido.")]
    public int IdLibro { get; set; }

    [Range(1, 100, ErrorMessage = "La cantidad debe estar entre 1 y 100.")]
    public int Cantidad { get; set; } = 1;
}

public class PrestamoActualizarDto
{
    /// <summary>"Activo" o "Devuelto".</summary>
    [Required, MaxLength(20)]
    public string Estado { get; set; } = string.Empty;
}
