using System.ComponentModel.DataAnnotations;

namespace BibliotecaAPI.DTOs;

public class LibroDto
{
    public int IdLibro { get; set; }
    public string Titulo { get; set; } = string.Empty;
    public string Autor { get; set; } = string.Empty;
    public string ISBN { get; set; } = string.Empty;
    public int CantidadDisponible { get; set; }
}

/// <summary>Datos para crear o actualizar un libro.</summary>
public class LibroGuardarDto
{
    [Required, MaxLength(150)]
    public string Titulo { get; set; } = string.Empty;

    [Required, MaxLength(100)]
    public string Autor { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    public string ISBN { get; set; } = string.Empty;

    [Range(0, 10000)]
    public int CantidadDisponible { get; set; }
}
